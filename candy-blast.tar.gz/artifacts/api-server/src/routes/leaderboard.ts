import { Router, type IRouter } from "express";
import { db } from "../lib/db";
import { leaderboardTable, insertLeaderboardSchema } from "@workspace/db";
import { desc, sql } from "drizzle-orm";

const router: IRouter = Router();

router.get("/leaderboard", async (_req, res) => {
  try {
    const entries = await db
      .select()
      .from(leaderboardTable)
      .orderBy(desc(leaderboardTable.score))
      .limit(20);
    res.json(entries);
  } catch (err) {
    res.status(500).json({ error: "Failed to fetch leaderboard" });
  }
});

router.post("/leaderboard", async (req, res) => {
  const parsed = insertLeaderboardSchema.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid data", details: parsed.error.issues });
  }
  try {
    const [entry] = await db.insert(leaderboardTable).values(parsed.data).returning();
    res.status(201).json(entry);
  } catch (err) {
    res.status(500).json({ error: "Failed to submit score" });
  }
});

export default router;
