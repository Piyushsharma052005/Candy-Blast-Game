import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import { GameBoard } from './GameBoard';
import { ScoreBar } from './ScoreBar';
import { LevelCompleteScreen } from './LevelCompleteScreen';
import { GameOverScreen } from './GameOverScreen';

export function GameScreen() {
  const { phase, goHome, pauseGame, resumeGame } = useGame();

  return (
    <div className="flex flex-col items-center justify-center min-h-screen px-3 py-4 gap-4">
      {/* Header */}
      <div className="flex items-center justify-between w-full max-w-xl">
        <button onClick={goHome}
          className="w-10 h-10 flex items-center justify-center rounded-xl text-white/70 hover:text-white transition-colors"
          style={{ background: 'rgba(155,89,182,0.2)' }}>
          🏠
        </button>
        <h1 className="text-lg font-black text-white tracking-[4px]"
          style={{ textShadow: '0 0 15px rgba(155,89,182,0.8)' }}>CANDY BLAST</h1>
        <button
          onClick={phase === 'paused' ? resumeGame : pauseGame}
          className="w-10 h-10 flex items-center justify-center rounded-xl text-white/70 hover:text-white transition-colors"
          style={{ background: 'rgba(155,89,182,0.2)' }}>
          {phase === 'paused' ? '▶' : '⏸'}
        </button>
      </div>

      {/* Score */}
      <div className="w-full max-w-xl">
        <ScoreBar />
      </div>

      {/* Board */}
      <div className="relative">
        <GameBoard />

        {/* Pause overlay */}
        <AnimatePresence>
          {phase === 'paused' && (
            <motion.div
              className="absolute inset-0 z-40 flex flex-col items-center justify-center gap-4 rounded-2xl"
              style={{ background: 'rgba(10,0,25,0.9)' }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <span className="text-6xl">⏸</span>
              <span className="text-white font-black text-3xl tracking-[4px]">PAUSED</span>
              <motion.button
                onClick={resumeGame}
                className="px-8 py-3 rounded-2xl text-white font-black text-lg tracking-widest"
                style={{ background: '#9B59B6', boxShadow: '0 4px 20px rgba(155,89,182,0.6)' }}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.96 }}
              >RESUME</motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Special guide */}
      <div className="w-full max-w-xl rounded-xl px-4 py-3 border"
        style={{ background: 'rgba(45,15,80,0.7)', borderColor: 'rgba(155,89,182,0.2)' }}>
        <p className="text-purple-400 text-[9px] font-black tracking-[2px] uppercase mb-2">Special Candies</p>
        <div className="flex flex-wrap gap-x-4 gap-y-1">
          {[
            { dot: '#5AA0FF', text: '4 in a row → Striped (clears row/col)' },
            { dot: '#FFD700', text: '5 in a row → Rainbow (clears a color)' },
            { dot: '#2ECC71', text: 'L-shape → Wrapped (5×5 blast)' },
          ].map(item => (
            <div key={item.text} className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: item.dot }} />
              <span className="text-purple-200 text-[10px]">{item.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Overlays */}
      <AnimatePresence>
        {phase === 'levelComplete' && <LevelCompleteScreen />}
        {phase === 'gameOver' && <GameOverScreen />}
      </AnimatePresence>
    </div>
  );
}
