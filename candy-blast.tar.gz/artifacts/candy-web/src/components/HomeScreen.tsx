import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import { LEVELS } from '@/lib/gameConfig';
import { LeaderboardPanel } from './LeaderboardPanel';
import { AdBanner } from './AdBanner';

const CANDY_LIST = [
  { sym: '♥', color: '#FF6B6B' }, { sym: '◆', color: '#5AA0FF' },
  { sym: '●', color: '#2ECC71' }, { sym: '★', color: '#FFD700' },
  { sym: '⬡', color: '#9B59B6' }, { sym: '■', color: '#FF8C00' },
];

function FloatingCandy({ sym, color, delay, startX }: { sym: string; color: string; delay: number; startX: string }) {
  return (
    <motion.div
      className="absolute text-3xl font-bold pointer-events-none select-none"
      style={{ left: startX, color, filter: `drop-shadow(0 0 8px ${color}88)` }}
      initial={{ y: '110vh', opacity: 0, rotate: 0 }}
      animate={{ y: '-10vh', opacity: [0, 0.9, 0.9, 0], rotate: 360 }}
      transition={{ duration: 6 + Math.random() * 4, delay, repeat: Infinity, repeatDelay: Math.random() * 3, ease: 'linear' }}
    >
      {sym}
    </motion.div>
  );
}

const TABS = ['play', 'levels', 'leaderboard'] as const;
type Tab = typeof TABS[number];

export function HomeScreen() {
  const { startGame, highScore } = useGame();
  const [tab, setTab] = useState<Tab>('play');
  const [floaters] = useState(() =>
    Array.from({ length: 14 }, (_, i) => ({
      ...CANDY_LIST[i % CANDY_LIST.length],
      delay: i * 0.5,
      startX: `${8 + (i * 7) % 85}%`,
    }))
  );

  return (
    <div className="relative flex flex-col items-center justify-start min-h-screen overflow-hidden px-4 py-6 gap-4">
      {/* Floating candies */}
      {floaters.map((f, i) => <FloatingCandy key={i} {...f} />)}

      {/* Logo */}
      <div className="relative z-10 flex flex-col items-center gap-1.5 mt-2">
        <motion.div
          className="text-3xl tracking-[8px] font-black"
          style={{ color: '#FFD700', filter: 'drop-shadow(0 0 12px #FFD700aa)' }}
          animate={{ filter: ['drop-shadow(0 0 8px #FFD700aa)', 'drop-shadow(0 0 22px #FFD700)', 'drop-shadow(0 0 8px #FFD700aa)'] }}
          transition={{ duration: 2, repeat: Infinity }}
        >♥◆●★</motion.div>
        <motion.h1
          className="text-5xl md:text-6xl font-black text-white tracking-widest text-center"
          style={{ textShadow: '0 0 30px rgba(255,107,107,0.7)' }}
          animate={{ textShadow: ['0 0 20px rgba(255,107,107,0.6)', '0 0 40px rgba(255,107,107,0.9)', '0 0 20px rgba(255,107,107,0.6)'] }}
          transition={{ duration: 2.5, repeat: Infinity }}
        >CANDY BLAST</motion.h1>
        <p className="text-purple-300 text-sm tracking-widest">20 Levels of Sweet Chaos</p>
      </div>

      {/* High score */}
      {highScore > 0 && (
        <motion.div
          className="relative z-10 flex items-center gap-2 px-5 py-2 rounded-full border"
          style={{ background: 'rgba(255,215,0,0.1)', borderColor: 'rgba(255,215,0,0.3)' }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <span className="text-yellow-400">🏆</span>
          <span className="text-yellow-400 text-sm font-medium">Best</span>
          <span className="text-yellow-300 text-lg font-black">{highScore.toLocaleString()}</span>
        </motion.div>
      )}

      {/* Play Button */}
      <motion.button
        className="relative z-10 flex items-center gap-3 text-white font-black text-2xl tracking-widest px-12 py-4 rounded-full"
        style={{ background: '#FF6B6B', boxShadow: '0 0 30px rgba(255,107,107,0.7)' }}
        onClick={() => startGame(1)}
        whileHover={{ scale: 1.06, boxShadow: '0 0 45px rgba(255,107,107,0.95)' }}
        whileTap={{ scale: 0.96 }}
        animate={{ scale: [1, 1.03, 1] }}
        transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
      >
        ▶ PLAY NOW
      </motion.button>

      {/* Tabs */}
      <div className="relative z-10 w-full max-w-xl flex flex-col gap-3">
        {/* Tab bar */}
        <div className="flex rounded-2xl overflow-hidden border" style={{ borderColor: 'rgba(155,89,182,0.3)', background: 'rgba(45,15,80,0.8)' }}>
          {([['play', '🎮 LEVELS'], ['leaderboard', '🏆 RANKINGS']] as [Tab, string][]).map(([t, label]) => (
            <button key={t} onClick={() => setTab(t)}
              className="flex-1 py-2.5 text-sm font-black tracking-wider transition-all duration-200"
              style={{
                background: tab === t ? '#9B59B6' : 'transparent',
                color: tab === t ? 'white' : '#9B59B6',
                boxShadow: tab === t ? '0 0 15px rgba(155,89,182,0.5)' : 'none',
              }}>
              {label}
            </button>
          ))}
        </div>

        {/* Tab content */}
        <AnimatePresence mode="wait">
          {tab === 'play' && (
            <motion.div key="play"
              className="rounded-2xl p-3 border"
              style={{ background: 'rgba(45,15,80,0.85)', borderColor: 'rgba(155,89,182,0.2)' }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <div className="grid grid-cols-4 gap-1.5">
                {LEVELS.map((lvl, i) => (
                  <motion.button key={i}
                    className="flex flex-col items-center px-1 py-2.5 rounded-xl border font-semibold"
                    style={{ background: 'rgba(155,89,182,0.12)', borderColor: 'rgba(155,89,182,0.28)' }}
                    whileHover={{ scale: 1.08, background: 'rgba(155,89,182,0.28)' }}
                    whileTap={{ scale: 0.94 }}
                    onClick={() => startGame(i + 1)}
                  >
                    <span className="text-xl leading-none">{lvl.badge}</span>
                    <span className="text-purple-400 text-sm font-black mt-0.5">{i + 1}</span>
                    <span className="text-purple-200 text-[8px] text-center leading-tight mt-0.5">{lvl.description}</span>
                    <span className="text-purple-500 text-[7px] mt-0.5">{lvl.target >= 1000 ? `${(lvl.target / 1000).toFixed(0)}K` : lvl.target}</span>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {tab === 'leaderboard' && (
            <motion.div key="lb"
              className="rounded-2xl p-4 border"
              style={{ background: 'rgba(45,15,80,0.85)', borderColor: 'rgba(155,89,182,0.2)' }}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
            >
              <div className="flex items-center gap-2 mb-3">
                <span className="text-yellow-400 text-lg">🏆</span>
                <span className="text-white font-black text-sm tracking-widest uppercase">Global Rankings</span>
              </div>
              <LeaderboardPanel />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Ad banner */}
      <div className="relative z-10 w-full max-w-xl">
        <AdBanner slot="1234567890" format="horizontal" className="rounded-xl overflow-hidden" />
      </div>

      {/* Feature badges */}
      <div className="relative z-10 flex gap-1.5 flex-wrap justify-center pb-4">
        {['20 Levels', 'Combos', 'Specials', 'Rainbow', 'Striped', 'Wrapped', 'Leaderboard'].map(b => (
          <span key={b} className="px-2.5 py-1 rounded-full text-[10px] font-semibold text-purple-400 border border-purple-700/50"
            style={{ background: 'rgba(155,89,182,0.1)' }}>{b}</span>
        ))}
      </div>
    </div>
  );
}
