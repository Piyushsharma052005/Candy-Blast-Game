import React from 'react';
import { useGame } from '@/context/GameContext';
import { CandyCell } from './CandyCell';
import { CELL_SIZE, GRID_COLS, GRID_ROWS } from '@/lib/gameConfig';
import { motion, AnimatePresence } from 'framer-motion';

export function GameBoard() {
  const { grid, selected, explodingIds, newSpecialIds, handleCandyClick, floatScores, shuffling } = useGame();

  if (!grid?.length) return null;

  const boardW = GRID_COLS * CELL_SIZE;
  const boardH = GRID_ROWS * CELL_SIZE;

  return (
    <div
      className="relative rounded-2xl overflow-hidden border border-purple-500/30"
      style={{
        width: boardW + 12,
        height: boardH + 12,
        background: 'rgba(45, 15, 80, 0.85)',
        boxShadow: '0 0 40px rgba(155, 89, 182, 0.35), inset 0 0 20px rgba(155,89,182,0.1)',
        padding: 6,
      }}
    >
      {/* Grid background */}
      <div
        className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(rgba(155,89,182,0.5) 1px, transparent 1px),
            linear-gradient(90deg, rgba(155,89,182,0.5) 1px, transparent 1px)
          `,
          backgroundSize: `${CELL_SIZE}px ${CELL_SIZE}px`,
          backgroundPosition: '6px 6px',
        }}
      />

      {/* Candy grid */}
      <div className="relative z-10">
        {grid.map((row, r) => (
          <div key={r} className="flex">
            {row.map((candy, c) => {
              if (!candy) return <div key={c} style={{ width: CELL_SIZE, height: CELL_SIZE }} />;
              return (
                <CandyCell
                  key={candy.id}
                  candy={candy}
                  isSelected={selected?.row === r && selected?.col === c}
                  isExploding={explodingIds.has(candy.id)}
                  isNewSpecial={newSpecialIds.has(candy.id)}
                  onClick={handleCandyClick}
                />
              );
            })}
          </div>
        ))}
      </div>

      {/* Float scores */}
      <AnimatePresence>
        {floatScores.map(fs => (
          <motion.div
            key={fs.id}
            className="absolute pointer-events-none font-black text-yellow-300 text-sm z-50"
            style={{ left: fs.x - 20, top: fs.y }}
            initial={{ y: 0, opacity: 1, scale: 0.8 }}
            animate={{ y: -55, opacity: 0, scale: 1.3 }}
            exit={{}}
            transition={{ duration: 0.85, ease: 'easeOut' }}
          >
            +{fs.value}
          </motion.div>
        ))}
      </AnimatePresence>

      {/* Shuffle overlay */}
      <AnimatePresence>
        {shuffling && (
          <motion.div
            className="absolute inset-0 z-50 flex flex-col items-center justify-center rounded-2xl gap-2"
            style={{ background: 'rgba(13,0,32,0.88)' }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <motion.span
              className="text-4xl"
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 0.8, repeat: Infinity, ease: 'linear' }}
            >⟳</motion.span>
            <span className="text-yellow-300 font-bold text-base tracking-widest">SHUFFLING...</span>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
