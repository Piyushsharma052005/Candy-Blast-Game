import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { submitScore } from '@/lib/api';

interface Props {
  score: number;
  level: number;
  onClose: () => void;
  onSuccess: () => void;
}

export function SubmitScoreModal({ score, level, onClose, onSuccess }: Props) {
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed || trimmed.length < 2) { setError('At least 2 characters'); return; }
    setLoading(true);
    setError('');
    try {
      await submitScore(trimmed.slice(0, 16), score, level);
      setSubmitted(true);
      setTimeout(onSuccess, 1400);
    } catch {
      setError('Failed to submit. Try again!');
    } finally {
      setLoading(false);
    }
  };

  return (
    <motion.div
      className="fixed inset-0 z-[60] flex items-center justify-center"
      style={{ background: 'rgba(0,0,0,0.7)' }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.div
        className="rounded-2xl p-6 flex flex-col gap-4 border w-full max-w-xs mx-4"
        style={{ background: '#1a0533', borderColor: 'rgba(155,89,182,0.5)', boxShadow: '0 0 40px rgba(155,89,182,0.5)' }}
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 200, damping: 15 }}
        onClick={e => e.stopPropagation()}
      >
        <AnimatePresence mode="wait">
          {!submitted ? (
            <motion.div key="form" className="flex flex-col gap-4" exit={{ opacity: 0, scale: 0.9 }}>
              <div className="text-center">
                <div className="text-4xl mb-1">🏆</div>
                <h3 className="text-white font-black text-xl">Submit Score</h3>
                <p className="text-purple-300 text-sm mt-1">
                  Score: <span className="text-yellow-400 font-bold">{score.toLocaleString()}</span>
                  {' · '}Level <span className="text-yellow-400 font-bold">{level}</span>
                </p>
              </div>
              <form onSubmit={handleSubmit} className="flex flex-col gap-3">
                <div>
                  <input
                    type="text"
                    placeholder="Your name (2-16 chars)"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    maxLength={16}
                    className="w-full px-4 py-2.5 rounded-xl text-white text-sm font-medium outline-none"
                    style={{
                      background: 'rgba(155,89,182,0.2)',
                      border: '1px solid rgba(155,89,182,0.4)',
                    }}
                    autoFocus
                  />
                  {error && <p className="text-red-400 text-xs mt-1 ml-1">{error}</p>}
                </div>
                <div className="flex gap-2">
                  <button type="button" onClick={onClose}
                    className="px-4 py-2.5 rounded-xl border text-purple-400 font-semibold text-sm"
                    style={{ borderColor: 'rgba(155,89,182,0.4)', background: 'rgba(155,89,182,0.1)' }}>
                    Skip
                  </button>
                  <motion.button
                    type="submit"
                    disabled={loading}
                    className="flex-1 py-2.5 rounded-xl text-white font-black text-sm tracking-wide"
                    style={{ background: '#9B59B6', boxShadow: '0 4px 15px rgba(155,89,182,0.5)', opacity: loading ? 0.7 : 1 }}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.97 }}
                  >
                    {loading ? '...' : '🚀 SUBMIT'}
                  </motion.button>
                </div>
              </form>
            </motion.div>
          ) : (
            <motion.div key="success" className="flex flex-col items-center gap-3 py-4"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}>
              <motion.div className="text-6xl"
                animate={{ rotate: [0, -10, 10, -5, 5, 0], scale: [1, 1.2, 1.2, 1] }}
                transition={{ duration: 0.6 }}>🎉</motion.div>
              <p className="text-white font-black text-xl">Score Submitted!</p>
              <p className="text-purple-300 text-sm text-center">You're on the leaderboard!</p>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </motion.div>
  );
}
