import React, { useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import { LEVELS } from '@/lib/gameConfig';

export function ScoreBar() {
  const { score, highScore, moves, maxMoves, level, combo, levelTarget } = useGame();
  const prevScore = useRef(score);
  const [scoreBounce, setScoreBounce] = React.useState(false);

  useEffect(() => {
    if (score !== prevScore.current) {
      setScoreBounce(true);
      setTimeout(() => setScoreBounce(false), 400);
      prevScore.current = score;
    }
  }, [score]);

  const progress = Math.min(score / levelTarget, 1);
  const movesLeft = maxMoves - moves;
  const warning = movesLeft <= 5;
  const lvlName = LEVELS[Math.min(level - 1, LEVELS.length - 1)].description;

  return (
    <div className="rounded-2xl p-4 flex flex-col gap-3"
      style={{ background: 'rgba(45, 15, 80, 0.9)', border: '1px solid rgba(155, 89, 182, 0.3)', boxShadow: '0 4px 20px rgba(107,79,187,0.3)' }}>

      {/* Top row */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold"
          style={{ background: 'rgba(155,89,182,0.25)', color: '#9B59B6' }}>
          <span>LVL {level}</span>
          <span className="text-purple-300 font-medium">{lvlName}</span>
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-yellow-400 text-sm">🏆</span>
          <span className="text-yellow-400 text-sm font-semibold">{highScore.toLocaleString()}</span>
        </div>
      </div>

      {/* Score + Combo */}
      <div className="flex items-center gap-3">
        <motion.div
          className="text-white font-black text-4xl tracking-tight"
          animate={scoreBounce ? { scale: [1, 1.28, 1] } : { scale: 1 }}
          transition={{ duration: 0.38 }}
        >
          {score.toLocaleString()}
        </motion.div>
        <AnimatePresence>
          {combo > 1 && (
            <motion.div
              className="px-3 py-1 rounded-full text-sm font-black text-white"
              style={{ background: '#FF6B6B', boxShadow: '0 0 16px rgba(255,107,107,0.7)' }}
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              transition={{ type: 'spring', stiffness: 400, damping: 10 }}
            >
              ×{combo} COMBO!
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Progress bar */}
      <div className="flex flex-col gap-1">
        <div className="h-2.5 rounded-full overflow-hidden relative" style={{ background: 'rgba(155,89,182,0.2)' }}>
          <motion.div
            className="h-full rounded-full"
            style={{ background: 'linear-gradient(90deg, #7d3cb5, #9B59B6, #b07cc6)', boxShadow: '0 0 8px rgba(155,89,182,0.8)' }}
            animate={{ width: `${progress * 100}%` }}
            transition={{ type: 'spring', stiffness: 120, damping: 20 }}
          />
          {/* Star at end */}
          <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 text-yellow-400 text-xs leading-none"
            style={{ left: `${progress * 100}%`, filter: 'drop-shadow(0 0 4px #FFD700)' }}>★</div>
        </div>
        <div className="text-right text-xs" style={{ color: '#b8a0d8' }}>
          {Math.floor(progress * 100)}% to goal · {levelTarget.toLocaleString()} pts
        </div>
      </div>

      {/* Moves */}
      <div className="flex items-center gap-2">
        <span className={`text-sm font-medium ${warning ? 'text-red-400' : 'text-purple-300'}`}>
          {warning ? '⚠' : '⇄'} {movesLeft} moves left
        </span>
        <div className="flex gap-1 ml-auto">
          {Array.from({ length: Math.min(maxMoves, 12) }).map((_, i) => (
            <div key={i}
              className="rounded-full transition-all duration-300"
              style={{
                width: 6, height: 6,
                background: i < Math.ceil((movesLeft / maxMoves) * 12)
                  ? warning ? '#FF6B6B' : '#9B59B6'
                  : 'rgba(155,89,182,0.18)',
              }}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
