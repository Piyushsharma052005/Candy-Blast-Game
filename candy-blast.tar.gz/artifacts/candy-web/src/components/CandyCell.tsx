import React, { memo, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Candy, CANDY_COLORS, CANDY_SYMBOLS, CELL_SIZE, SpecialType } from '@/lib/gameConfig';

function SpecialMarker({ special }: { special: SpecialType }) {
  if (!special) return null;
  if (special === 'striped_h') return (
    <div className="absolute inset-0 flex flex-col justify-around items-center pointer-events-none rounded-full overflow-hidden">
      {[0,1,2].map(i => <div key={i} className="w-full h-[2.5px] bg-white/70" />)}
    </div>
  );
  if (special === 'striped_v') return (
    <div className="absolute inset-0 flex flex-row justify-around items-center pointer-events-none rounded-full overflow-hidden">
      {[0,1,2].map(i => <div key={i} className="h-full w-[2.5px] bg-white/70" />)}
    </div>
  );
  if (special === 'bomb') return (
    <div className="absolute inset-0 flex items-center justify-center pointer-events-none text-[13px]">💥</div>
  );
  if (special === 'wrapped') return (
    <div className="absolute inset-0 rounded-full border-2 border-white/80 pointer-events-none overflow-hidden flex items-center justify-center">
      <div className="absolute w-full h-[2px] bg-white/70" />
      <div className="absolute h-full w-[2px] bg-white/70" />
    </div>
  );
  if (special === 'rainbow') return (
    <div className="absolute inset-0 rounded-full pointer-events-none overflow-hidden"
      style={{ background: 'linear-gradient(135deg, #FF6B6B, #FFD700, #2ECC71, #3B8BFF, #9B59B6)', opacity: 0.6 }} />
  );
  return null;
}

interface Props {
  candy: Candy;
  isSelected: boolean;
  isExploding: boolean;
  isNewSpecial: boolean;
  onClick: (row: number, col: number) => void;
}

export const CandyCell = memo(function CandyCell({ candy, isSelected, isExploding, isNewSpecial, onClick }: Props) {
  const { base, mid, light, glow } = CANDY_COLORS[candy.type];

  const variants = {
    initial: { scale: 0, rotate: -15, opacity: 0 },
    animate: { scale: 1, rotate: 0, opacity: 1 },
    exit: { scale: 0, rotate: 180, opacity: 0 },
    explode: { scale: [1, 1.5, 0], rotate: [0, 90, 180], opacity: [1, 0.8, 0] },
    newSpecial: { scale: [1, 1.6, 0.9, 1.1, 1] },
  };

  return (
    <motion.div
      className="flex items-center justify-center cursor-pointer select-none"
      style={{ width: CELL_SIZE, height: CELL_SIZE }}
      onClick={() => onClick(candy.row, candy.col)}
      whileHover={{ scale: 1.08 }}
      whileTap={{ scale: 0.92 }}
    >
      <motion.div
        key={candy.id}
        className="relative flex items-center justify-center rounded-full"
        style={{
          width: CELL_SIZE - 8,
          height: CELL_SIZE - 8,
          background: `radial-gradient(circle at 35% 30%, ${light}, ${mid} 50%, ${base})`,
          boxShadow: isSelected
            ? `0 0 0 2.5px #fff, 0 0 16px 4px ${glow}cc, 0 0 30px 8px ${glow}66`
            : `inset 0 -3px 6px rgba(0,0,0,0.35), 0 3px 8px rgba(0,0,0,0.4), 0 0 10px ${glow}44`,
          border: isSelected ? '2px solid white' : '1px solid rgba(255,255,255,0.2)',
        }}
        initial={candy.isNew ? 'initial' : undefined}
        animate={
          isExploding ? 'explode' :
          isNewSpecial ? 'newSpecial' :
          'animate'
        }
        variants={variants}
        transition={{
          type: isExploding ? 'tween' : 'spring',
          duration: isExploding ? 0.38 : undefined,
          damping: 12, stiffness: 280,
          times: isExploding ? [0, 0.5, 1] : isNewSpecial ? [0, 0.3, 0.6, 0.8, 1] : undefined,
        }}
      >
        {/* Shine */}
        <div
          className="absolute rounded-full pointer-events-none"
          style={{ width: 14, height: 10, top: 4, left: 6, background: `${light}66`, transform: 'rotate(-20deg)', borderRadius: 8 }}
        />
        {/* Symbol */}
        <span className="text-white font-bold text-[17px] relative z-10 drop-shadow-sm select-none">
          {CANDY_SYMBOLS[candy.type]}
        </span>
        {/* Special overlay */}
        <SpecialMarker special={candy.special} />
        {/* Selected ring pulse */}
        {isSelected && (
          <motion.div
            className="absolute inset-[-3px] rounded-full border-2 border-white/80 pointer-events-none"
            animate={{ opacity: [1, 0.4, 1], scale: [1, 1.08, 1] }}
            transition={{ duration: 0.8, repeat: Infinity }}
          />
        )}
      </motion.div>
    </motion.div>
  );
});
