import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { fetchLeaderboard, type LeaderboardEntry } from '@/lib/api';

const MEDALS = ['🥇', '🥈', '🥉'];
const RANK_COLORS = ['#FFD700', '#C0C0C0', '#CD7F32'];

function timeAgo(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

export function LeaderboardPanel() {
  const [entries, setEntries] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    fetchLeaderboard()
      .then(data => { setEntries(data); setLoading(false); })
      .catch(() => { setError(true); setLoading(false); });
  }, []);

  if (loading) return (
    <div className="flex flex-col items-center justify-center py-10 gap-3">
      <motion.div
        className="text-4xl"
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
      >⟳</motion.div>
      <span className="text-purple-300 text-sm">Loading rankings...</span>
    </div>
  );

  if (error) return (
    <div className="flex flex-col items-center justify-center py-8 gap-2">
      <span className="text-3xl">📡</span>
      <span className="text-purple-400 text-sm text-center">Could not connect to server.<br/>Play a game to submit your score!</span>
    </div>
  );

  if (entries.length === 0) return (
    <div className="flex flex-col items-center justify-center py-8 gap-2">
      <span className="text-3xl">🏆</span>
      <span className="text-purple-400 text-sm text-center">No scores yet!<br/>Be the first champion.</span>
    </div>
  );

  return (
    <div className="flex flex-col gap-2 max-h-72 overflow-y-auto pr-1 scrollbar-thin">
      <AnimatePresence>
        {entries.map((entry, i) => (
          <motion.div
            key={entry.id}
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl border"
            style={{
              background: i < 3 ? `rgba(${i === 0 ? '255,215,0' : i === 1 ? '192,192,192' : '205,127,50'},0.08)` : 'rgba(155,89,182,0.08)',
              borderColor: i < 3 ? `rgba(${i === 0 ? '255,215,0' : i === 1 ? '192,192,192' : '205,127,50'},0.3)` : 'rgba(155,89,182,0.2)',
            }}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.04 }}
          >
            {/* Rank */}
            <div className="w-8 text-center font-black text-lg flex-shrink-0">
              {i < 3 ? MEDALS[i] : <span className="text-purple-400 text-sm">#{i + 1}</span>}
            </div>
            {/* Name + level */}
            <div className="flex-1 min-w-0">
              <p className="text-white font-bold text-sm truncate"
                style={{ color: i < 3 ? RANK_COLORS[i] : 'white' }}>
                {entry.playerName}
              </p>
              <p className="text-purple-400 text-xs">Level {entry.level} · {timeAgo(entry.createdAt)}</p>
            </div>
            {/* Score */}
            <div className="flex-shrink-0 text-right">
              <span className="font-black text-sm"
                style={{ color: i < 3 ? RANK_COLORS[i] : '#d4b6f0' }}>
                {entry.score.toLocaleString()}
              </span>
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
