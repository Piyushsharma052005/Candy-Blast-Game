import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import { SubmitScoreModal } from './SubmitScoreModal';
import { AdBanner } from './AdBanner';

export function GameOverScreen() {
  const { score, highScore, level, restartLevel, goHome } = useGame();
  const [showSubmit, setShowSubmit] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const isNewHigh = score > 0 && score >= highScore;

  return (
    <>
      <div className="fixed inset-0 flex items-center justify-center z-50 px-4" style={{ background: 'rgba(10,0,25,0.93)' }}>
        <motion.div
          className="rounded-3xl p-6 flex flex-col items-center gap-4 border w-full max-w-sm"
          style={{ background: '#2d0f50', borderColor: 'rgba(255,107,107,0.4)', boxShadow: '0 0 50px rgba(255,107,107,0.4)' }}
          initial={{ scale: 0.3, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 180, damping: 14 }}
        >
          <motion.div className="text-6xl"
            initial={{ scale: 0, rotate: -20 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ type: 'spring', stiffness: 200, damping: 10 }}>
            😢
          </motion.div>

          <div className="text-center">
            <h2 className="text-4xl font-black text-red-400 tracking-wider"
              style={{ textShadow: '0 0 20px rgba(255,107,107,0.7)' }}>GAME OVER</h2>
            <p className="text-purple-300 text-sm">Level {level} — so close!</p>
          </div>

          {isNewHigh && (
            <motion.div className="flex items-center gap-2 px-4 py-2 rounded-full border"
              style={{ background: 'rgba(255,215,0,0.12)', borderColor: 'rgba(255,215,0,0.35)' }}
              initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 0.4, type: 'spring' }}>
              <span className="text-yellow-400">🏆</span>
              <span className="text-yellow-400 text-sm font-black tracking-widest">NEW HIGH SCORE!</span>
            </motion.div>
          )}

          <div className="flex gap-3 w-full">
            <div className="flex-1 flex flex-col items-center py-4 rounded-xl" style={{ background: 'rgba(155,89,182,0.12)' }}>
              <span className="text-purple-300 text-xs font-semibold uppercase tracking-wider">Score</span>
              <span className="text-white text-3xl font-black">{score.toLocaleString()}</span>
            </div>
            <div className="flex-1 flex flex-col items-center py-4 rounded-xl" style={{ background: 'rgba(255,215,0,0.08)' }}>
              <span className="text-yellow-400 text-xs font-semibold uppercase tracking-wider">Best</span>
              <span className="text-yellow-300 text-3xl font-black">{highScore.toLocaleString()}</span>
            </div>
          </div>

          {/* Ad */}
          <AdBanner slot="1122334455" format="rectangle" className="w-full rounded-xl overflow-hidden" />

          <div className="flex items-start gap-2 px-4 py-3 rounded-xl border w-full"
            style={{ background: 'rgba(155,89,182,0.1)', borderColor: 'rgba(155,89,182,0.2)' }}>
            <span className="text-purple-400 text-sm mt-0.5">💡</span>
            <p className="text-purple-200 text-xs leading-relaxed">
              Match 4+ candies to create powerful special candies! Rainbow clears an entire color!
            </p>
          </div>

          <div className="flex gap-2 w-full">
            <button onClick={goHome}
              className="px-4 py-3 rounded-xl border font-bold text-purple-400 text-lg"
              style={{ background: 'rgba(155,89,182,0.15)', borderColor: 'rgba(155,89,182,0.4)' }}>
              🏠
            </button>
            {score > 0 && !submitted && (
              <button onClick={() => setShowSubmit(true)}
                className="px-3 py-3 rounded-xl border font-bold text-yellow-400 text-xs"
                style={{ background: 'rgba(255,215,0,0.1)', borderColor: 'rgba(255,215,0,0.3)' }}>
                🏆 Submit
              </button>
            )}
            <motion.button
              onClick={restartLevel}
              className="flex-1 flex items-center justify-center gap-1 py-3 rounded-xl font-black text-white text-sm tracking-wide"
              style={{ background: '#FF6B6B', boxShadow: '0 4px 20px rgba(255,107,107,0.5)' }}
              whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}>
              ↻ TRY AGAIN
            </motion.button>
          </div>
        </motion.div>
      </div>

      <AnimatePresence>
        {showSubmit && !submitted && (
          <SubmitScoreModal
            score={score}
            level={level}
            onClose={() => setShowSubmit(false)}
            onSuccess={() => { setSubmitted(true); setShowSubmit(false); }}
          />
        )}
      </AnimatePresence>
    </>
  );
}
