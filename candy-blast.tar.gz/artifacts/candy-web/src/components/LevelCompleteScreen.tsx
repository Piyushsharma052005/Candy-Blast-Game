import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useGame } from '@/context/GameContext';
import { LEVELS } from '@/lib/gameConfig';
import { SubmitScoreModal } from './SubmitScoreModal';
import { AdBanner } from './AdBanner';

export function LevelCompleteScreen() {
  const { score, level, moves, maxMoves, nextLevel, goHome } = useGame();
  const [showSubmit, setShowSubmit] = useState(true);
  const [submitted, setSubmitted] = useState(false);

  const starsEarned = moves <= maxMoves * 0.45 ? 3 : moves <= maxMoves * 0.7 ? 2 : 1;
  const nextLvl = Math.min(level + 1, LEVELS.length);
  const nextCfg = LEVELS[nextLvl - 1];
  const isLastLevel = level >= LEVELS.length;

  return (
    <>
      <div className="fixed inset-0 flex items-center justify-center z-50 px-4" style={{ background: 'rgba(10,0,25,0.92)' }}>
        <motion.div
          className="rounded-3xl p-6 flex flex-col items-center gap-4 border w-full max-w-sm"
          style={{ background: '#2d0f50', borderColor: 'rgba(155,89,182,0.5)', boxShadow: '0 0 50px rgba(155,89,182,0.5)' }}
          initial={{ scale: 0.3, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: 'spring', stiffness: 180, damping: 14 }}
        >
          {/* Stars */}
          <div className="flex gap-3">
            {[0, 1, 2].map(i => (
              <motion.span key={i} className="text-5xl"
                style={{ filter: i < starsEarned ? 'drop-shadow(0 0 10px #FFD700)' : 'none', opacity: i < starsEarned ? 1 : 0.18 }}
                initial={{ scale: 0, rotate: -30 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: i * 0.2, type: 'spring', stiffness: 200, damping: 12 }}
              >★</motion.span>
            ))}
          </div>

          {/* Badge + title */}
          <div className="text-center">
            <motion.span className="text-4xl block mb-1"
              animate={{ y: [0, -8, 0] }} transition={{ duration: 1.5, repeat: Infinity }}>
              {LEVELS[Math.min(level - 1, LEVELS.length - 1)].badge}
            </motion.span>
            <h2 className="text-3xl font-black text-yellow-400" style={{ textShadow: '0 0 20px rgba(255,215,0,0.7)' }}>
              LEVEL {level} DONE!
            </h2>
            <p className="text-purple-300 text-xs mt-0.5">{LEVELS[Math.min(level - 1, LEVELS.length - 1)].description}</p>
          </div>

          {/* Score */}
          <div className="flex flex-col items-center px-8 py-3 rounded-2xl border w-full"
            style={{ background: 'rgba(155,89,182,0.15)', borderColor: 'rgba(155,89,182,0.3)' }}>
            <span className="text-purple-300 text-xs tracking-widest uppercase font-semibold">Score</span>
            <span className="text-white text-5xl font-black">{score.toLocaleString()}</span>
          </div>

          {/* Stats */}
          <div className="flex gap-2 w-full">
            {[
              { icon: '⇄', label: 'Used', value: moves },
              { icon: '★', label: 'Stars', value: `${starsEarned}/3` },
              { icon: '🎯', label: 'Next', value: `Lvl ${nextLvl}` },
            ].map(s => (
              <div key={s.label} className="flex-1 flex flex-col items-center gap-0.5 rounded-xl py-2.5"
                style={{ background: 'rgba(155,89,182,0.12)' }}>
                <span className="text-base">{s.icon}</span>
                <span className="text-white text-sm font-bold">{s.value}</span>
                <span className="text-purple-400 text-[8px] font-medium uppercase tracking-wide">{s.label}</span>
              </div>
            ))}
          </div>

          {/* Ad */}
          <AdBanner slot="0987654321" format="rectangle" className="w-full rounded-xl overflow-hidden" />

          {/* Next level preview */}
          {!isLastLevel && (
            <div className="w-full flex items-center gap-2 px-3 py-2 rounded-xl border"
              style={{ background: 'rgba(255,215,0,0.08)', borderColor: 'rgba(255,215,0,0.2)' }}>
              <span className="text-xl">{nextCfg.badge}</span>
              <div>
                <p className="text-yellow-400 text-xs font-bold">Next: {nextCfg.description}</p>
                <p className="text-purple-300 text-[10px]">{nextCfg.target.toLocaleString()} pts · {nextCfg.moves} moves</p>
              </div>
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-2 w-full">
            <button onClick={goHome}
              className="px-4 py-3 rounded-xl border font-bold text-purple-400 text-lg"
              style={{ background: 'rgba(155,89,182,0.15)', borderColor: 'rgba(155,89,182,0.4)' }}>
              🏠
            </button>
            {!submitted && (
              <button onClick={() => setShowSubmit(true)}
                className="px-4 py-3 rounded-xl border font-bold text-yellow-400 text-sm"
                style={{ background: 'rgba(255,215,0,0.1)', borderColor: 'rgba(255,215,0,0.3)' }}>
                🏆 Submit
              </button>
            )}
            <motion.button
              onClick={isLastLevel ? goHome : nextLevel}
              className="flex-1 flex items-center justify-center gap-1 py-3 rounded-xl font-black text-white text-sm tracking-wide"
              style={{ background: '#9B59B6', boxShadow: '0 4px 20px rgba(155,89,182,0.5)' }}
              whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.97 }}
            >
              {isLastLevel ? '🎯 YOU WIN!' : 'NEXT →'}
            </motion.button>
          </div>
        </motion.div>
      </div>

      <AnimatePresence>
        {showSubmit && !submitted && (
          <SubmitScoreModal
            score={score}
            level={level}
            onClose={() => setShowSubmit(false)}
            onSuccess={() => { setSubmitted(true); setShowSubmit(false); }}
          />
        )}
      </AnimatePresence>
    </>
  );
}
