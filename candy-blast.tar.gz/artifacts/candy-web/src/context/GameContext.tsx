import React, { createContext, useCallback, useContext, useRef, useState, useEffect } from 'react';
import { Candy, GRID_COLS, GRID_ROWS, LEVELS } from '@/lib/gameConfig';
import {
  createInitialGrid, findMatches, applyGravity, swap, isAdjacent,
  hasMoves, applySpecialEffect, calcScore, specialForLength, getMatchLen, makeCandy,
} from '@/lib/gameEngine';

export type GamePhase = 'home' | 'playing' | 'paused' | 'levelComplete' | 'gameOver';

interface FloatScore { id: string; value: number; x: number; y: number; }

interface Ctx {
  grid: Candy[][];
  score: number;
  highScore: number;
  moves: number;
  maxMoves: number;
  level: number;
  combo: number;
  phase: GamePhase;
  selected: { row: number; col: number } | null;
  floatScores: FloatScore[];
  levelTarget: number;
  explodingIds: Set<string>;
  newSpecialIds: Set<string>;
  shuffling: boolean;
  handleCandyClick: (row: number, col: number) => void;
  startGame: (lvl?: number) => void;
  nextLevel: () => void;
  restartLevel: () => void;
  goHome: () => void;
  pauseGame: () => void;
  resumeGame: () => void;
}

const GameCtx = createContext<Ctx | null>(null);
const HS_KEY = 'candyblast_web_hs';

const delay = (ms: number) => new Promise<void>(r => setTimeout(r, ms));

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [grid, setGrid] = useState<Candy[][]>([]);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => parseInt(localStorage.getItem(HS_KEY) ?? '0', 10));
  const [moves, setMoves] = useState(0);
  const [maxMoves, setMaxMoves] = useState(20);
  const [level, setLevel] = useState(1);
  const [combo, setCombo] = useState(0);
  const [phase, setPhase] = useState<GamePhase>('home');
  const [selected, setSelected] = useState<{ row: number; col: number } | null>(null);
  const [floatScores, setFloatScores] = useState<FloatScore[]>([]);
  const [explodingIds, setExplodingIds] = useState<Set<string>>(new Set());
  const [newSpecialIds, setNewSpecialIds] = useState<Set<string>>(new Set());
  const [shuffling, setShuffling] = useState(false);

  const busy = useRef(false);
  const scoreRef = useRef(0);
  const phaseRef = useRef<GamePhase>('home');

  useEffect(() => { phaseRef.current = phase; }, [phase]);
  useEffect(() => { scoreRef.current = score; }, [score]);

  const cfg = LEVELS[Math.min(level - 1, LEVELS.length - 1)];
  const levelTarget = cfg.target;

  const spawnFloat = useCallback((points: number, row: number, col: number) => {
    const id = Date.now() + Math.random() + '';
    setFloatScores(p => [...p, { id, value: points, x: col * 52 + 26, y: row * 52 + 10 }]);
    setTimeout(() => setFloatScores(p => p.filter(s => s.id !== id)), 900);
  }, []);

  const updateHighScore = useCallback((s: number) => {
    setHighScore(prev => {
      const next = Math.max(prev, s);
      localStorage.setItem(HS_KEY, next.toString());
      return next;
    });
  }, []);

  const processGrid = useCallback(async (g: Candy[][], comboStart: number, scoreStart: number): Promise<number> => {
    let workGrid = g;
    let workCombo = comboStart;
    let workScore = scoreStart;

    while (true) {
      const matched = findMatches(workGrid);
      if (matched.size === 0) break;

      // Collect specials to fire
      let allExploded = new Set(matched);
      let hasSpecial = false;
      workGrid.forEach(row => row.forEach(c => {
        if (c?.special && matched.has(c.id)) {
          hasSpecial = true;
          applySpecialEffect(workGrid, c).forEach(id => allExploded.add(id));
        }
      }));

      workCombo++;
      const pts = calcScore(allExploded.size, workCombo, hasSpecial);
      workScore += pts;

      // Find best match location for float score
      let firstRow = 0, firstCol = 0;
      outer: for (let r = 0; r < GRID_ROWS; r++) for (let c = 0; c < GRID_COLS; c++) {
        if (workGrid[r]?.[c] && allExploded.has(workGrid[r][c].id)) { firstRow = r; firstCol = c; break outer; }
      }
      spawnFloat(pts, firstRow, firstCol);

      setExplodingIds(new Set(allExploded));
      await delay(360);

      // Mark matched
      workGrid = workGrid.map(row => row.map(c => c && allExploded.has(c.id) ? { ...c, isMatched: true } : c));

      // Create specials for long chains
      const newSpecials = new Set<string>();
      matched.forEach(id => {
        let row = -1, col = -1;
        workGrid.forEach((r, ri) => r.forEach((c, ci) => { if (c?.id === id) { row = ri; col = ci; } }));
        if (row < 0) return;
        const len = getMatchLen(workGrid, row, col);
        const special = specialForLength(len);
        if (special && workGrid[row]?.[col]) {
          workGrid[row][col] = { ...workGrid[row][col], special, isMatched: false };
          newSpecials.add(id);
        }
      });

      workGrid = applyGravity(workGrid);
      setNewSpecialIds(newSpecials);
      setGrid([...workGrid]);
      setScore(workScore);
      setCombo(workCombo);
      setExplodingIds(new Set());
      await delay(300);
    }

    setCombo(0);
    updateHighScore(workScore);
    return workScore;
  }, [spawnFloat, updateHighScore]);

  const handleCandyClick = useCallback(async (row: number, col: number) => {
    if (busy.current || phaseRef.current !== 'playing') return;

    if (!selected) { setSelected({ row, col }); return; }
    const { row: sr, col: sc } = selected;
    setSelected(null);
    if (sr === row && sc === col) return;
    if (!isAdjacent(sr, sc, row, col)) { setSelected({ row, col }); return; }

    const swapped = swap(grid, sr, sc, row, col);
    if (findMatches(swapped).size === 0) { return; }

    busy.current = true;
    const newMoves = moves + 1;
    setMoves(newMoves);
    setGrid([...swapped]);

    const finalScore = await processGrid(swapped, 0, scoreRef.current);

    if (finalScore >= levelTarget) {
      setPhase('levelComplete');
      busy.current = false;
      return;
    }
    if (newMoves >= maxMoves) {
      setPhase('gameOver');
      busy.current = false;
      return;
    }
    if (!hasMoves(swapped)) {
      setShuffling(true);
      await delay(500);
      setGrid(createInitialGrid());
      setShuffling(false);
    }
    busy.current = false;
  }, [grid, selected, moves, maxMoves, levelTarget, processGrid]);

  const startGame = useCallback((lvl = 1) => {
    const c = LEVELS[Math.min(lvl - 1, LEVELS.length - 1)];
    setLevel(lvl);
    setMaxMoves(c.moves);
    setScore(0);
    setMoves(0);
    setCombo(0);
    setSelected(null);
    setFloatScores([]);
    setExplodingIds(new Set());
    setNewSpecialIds(new Set());
    setGrid(createInitialGrid());
    setPhase('playing');
    busy.current = false;
  }, []);

  const nextLevel = useCallback(() => startGame(level + 1), [level, startGame]);
  const restartLevel = useCallback(() => startGame(level), [level, startGame]);
  const goHome = useCallback(() => { setPhase('home'); setSelected(null); busy.current = false; }, []);
  const pauseGame = useCallback(() => setPhase('paused'), []);
  const resumeGame = useCallback(() => setPhase('playing'), []);

  return (
    <GameCtx.Provider value={{
      grid, score, highScore, moves, maxMoves, level, combo, phase, selected,
      floatScores, levelTarget, explodingIds, newSpecialIds, shuffling,
      handleCandyClick, startGame, nextLevel, restartLevel, goHome, pauseGame, resumeGame,
    }}>
      {children}
    </GameCtx.Provider>
  );
}

export function useGame() {
  const c = useContext(GameCtx);
  if (!c) throw new Error('useGame must be inside GameProvider');
  return c;
}
