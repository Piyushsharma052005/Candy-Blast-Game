import { Router as WouterRouter, Switch, Route } from "wouter";
import { GameProvider, useGame } from "@/context/GameContext";
import { HomeScreen } from "@/components/HomeScreen";
import { GameScreen } from "@/components/GameScreen";

function Game() {
  const { phase } = useGame();
  const isPlaying = phase === 'playing' || phase === 'paused' || phase === 'levelComplete' || phase === 'gameOver';
  return isPlaying ? <GameScreen /> : <HomeScreen />;
}

function App() {
  return (
    <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
      <GameProvider>
        <Switch>
          <Route path="/" component={Game} />
          <Route path="*" component={Game} />
        </Switch>
      </GameProvider>
    </WouterRouter>
  );
}

export default App;
