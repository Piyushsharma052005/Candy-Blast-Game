export const GRID_COLS = 8;
export const GRID_ROWS = 8;
export const CELL_SIZE = 52;

export const CANDY_TYPES = ['red', 'blue', 'green', 'yellow', 'purple', 'orange'] as const;
export type CandyType = typeof CANDY_TYPES[number];

export const SPECIAL_TYPES = ['bomb', 'striped_h', 'striped_v', 'wrapped', 'rainbow'] as const;
export type SpecialType = typeof SPECIAL_TYPES[number] | null;

export interface Candy {
  id: string;
  type: CandyType;
  special: SpecialType;
  row: number;
  col: number;
  isMatched: boolean;
  isNew: boolean;
}

export const CANDY_COLORS: Record<CandyType, { base: string; mid: string; light: string; glow: string }> = {
  red:    { base: '#e62222', mid: '#FF4444', light: '#FF7777', glow: '#ff4444' },
  blue:   { base: '#1a6fd4', mid: '#3B8BFF', light: '#7BBFFF', glow: '#3B8BFF' },
  green:  { base: '#1aaa58', mid: '#2ECC71', light: '#55ee99', glow: '#2ECC71' },
  yellow: { base: '#d4a000', mid: '#FFD700', light: '#FFE966', glow: '#FFD700' },
  purple: { base: '#7d3cb5', mid: '#9B59B6', light: '#C49FD6', glow: '#9B59B6' },
  orange: { base: '#cc6600', mid: '#FF8C00', light: '#FFB555', glow: '#FF8C00' },
};

export const CANDY_SYMBOLS: Record<CandyType, string> = {
  red: '♥', blue: '◆', green: '●', yellow: '★', purple: '⬡', orange: '■',
};

export const LEVELS = [
  { target: 500,   moves: 18, description: 'First Bite',      badge: '🍬' },
  { target: 1000,  moves: 20, description: 'Sweet Start',     badge: '🍭' },
  { target: 1800,  moves: 22, description: 'Sugar Rush',      badge: '🍡' },
  { target: 2800,  moves: 24, description: 'Candy Storm',     badge: '🍫' },
  { target: 4000,  moves: 26, description: 'Jelly Blast',     badge: '🍮' },
  { target: 5500,  moves: 28, description: 'Rainbow Frenzy',  badge: '🌈' },
  { target: 7000,  moves: 30, description: 'Mega Crush',      badge: '💎' },
  { target: 9000,  moves: 30, description: 'Candy Fever',     badge: '🔥' },
  { target: 11000, moves: 28, description: 'Sugar Overload',  badge: '⚡' },
  { target: 13500, moves: 28, description: 'Blizzard Blast',  badge: '❄️' },
  { target: 16000, moves: 26, description: 'Cosmic Candy',    badge: '🌌' },
  { target: 19000, moves: 26, description: 'Sweet Thunder',   badge: '⛈️' },
  { target: 22000, moves: 24, description: 'Inferno Rush',    badge: '🌋' },
  { target: 26000, moves: 24, description: 'Diamond Storm',   badge: '💠' },
  { target: 30000, moves: 22, description: 'Galaxy Crush',    badge: '🌠' },
  { target: 35000, moves: 22, description: 'Neon Frenzy',     badge: '🎆' },
  { target: 40000, moves: 20, description: 'Epic Blast',      badge: '🏆' },
  { target: 46000, moves: 20, description: 'Legend Rush',     badge: '👑' },
  { target: 53000, moves: 18, description: 'Godlike Crush',   badge: '⭐' },
  { target: 60000, moves: 18, description: 'Ultimate Blast',  badge: '🎯' },
] as const;

export type Level = typeof LEVELS[number];
