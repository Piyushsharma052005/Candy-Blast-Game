const BASE = '/api';

export interface LeaderboardEntry {
  id: number;
  playerName: string;
  score: number;
  level: number;
  createdAt: string;
}

export async function fetchLeaderboard(): Promise<LeaderboardEntry[]> {
  const res = await fetch(`${BASE}/leaderboard`);
  if (!res.ok) throw new Error('Failed to fetch leaderboard');
  return res.json();
}

export async function submitScore(playerName: string, score: number, level: number): Promise<LeaderboardEntry> {
  const res = await fetch(`${BASE}/leaderboard`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ playerName, score, level }),
  });
  if (!res.ok) throw new Error('Failed to submit score');
  return res.json();
}
