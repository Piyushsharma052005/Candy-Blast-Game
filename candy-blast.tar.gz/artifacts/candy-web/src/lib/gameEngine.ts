import { Candy, CandyType, CANDY_TYPES, GRID_COLS, GRID_ROWS, SpecialType } from './gameConfig';

export function genId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

export function randType(): CandyType {
  return CANDY_TYPES[Math.floor(Math.random() * CANDY_TYPES.length)];
}

export function makeCandy(row: number, col: number, type?: CandyType): Candy {
  return { id: genId(), type: type ?? randType(), special: null, row, col, isMatched: false, isNew: true };
}

export function createInitialGrid(): Candy[][] {
  const grid: Candy[][] = [];
  for (let r = 0; r < GRID_ROWS; r++) {
    grid[r] = [];
    for (let c = 0; c < GRID_COLS; c++) {
      let type: CandyType, attempts = 0;
      do {
        type = randType();
        attempts++;
      } while (
        attempts < 12 &&
        ((c >= 2 && grid[r][c-1]?.type === type && grid[r][c-2]?.type === type) ||
         (r >= 2 && grid[r-1]?.[c]?.type === type && grid[r-2]?.[c]?.type === type))
      );
      grid[r][c] = makeCandy(r, c, type);
    }
  }
  return grid;
}

export function findMatches(grid: Candy[][]): Set<string> {
  const matched = new Set<string>();
  // Horizontal
  for (let r = 0; r < GRID_ROWS; r++) {
    for (let c = 0; c < GRID_COLS - 2; c++) {
      const t = grid[r][c]?.type;
      if (!t) continue;
      let len = 1;
      while (c + len < GRID_COLS && grid[r][c + len]?.type === t) len++;
      if (len >= 3) for (let k = 0; k < len; k++) matched.add(grid[r][c + k].id);
    }
  }
  // Vertical
  for (let c = 0; c < GRID_COLS; c++) {
    for (let r = 0; r < GRID_ROWS - 2; r++) {
      const t = grid[r][c]?.type;
      if (!t) continue;
      let len = 1;
      while (r + len < GRID_ROWS && grid[r + len]?.[c]?.type === t) len++;
      if (len >= 3) for (let k = 0; k < len; k++) matched.add(grid[r + k][c].id);
    }
  }
  return matched;
}

export function getMatchLen(grid: Candy[][], row: number, col: number): number {
  if (!grid[row]?.[col]) return 3;
  const t = grid[row][col].type;
  let hS = col; while (hS > 0 && grid[row][hS-1]?.type === t) hS--;
  let hL = 1; while (hS + hL < GRID_COLS && grid[row][hS+hL]?.type === t) hL++;
  let vS = row; while (vS > 0 && grid[vS-1]?.[col]?.type === t) vS--;
  let vL = 1; while (vS + vL < GRID_ROWS && grid[vS+vL]?.[col]?.type === t) vL++;
  return Math.max(hL, vL);
}

export function specialForLength(len: number): SpecialType {
  if (len >= 5) return 'rainbow';
  if (len >= 4) return Math.random() > 0.5 ? 'striped_h' : 'striped_v';
  return null;
}

export function applySpecialEffect(grid: Candy[][], candy: Candy): Set<string> {
  const ids = new Set<string>();
  if (candy.special === 'striped_h') {
    for (let c = 0; c < GRID_COLS; c++) if (grid[candy.row]?.[c]) ids.add(grid[candy.row][c].id);
  } else if (candy.special === 'striped_v') {
    for (let r = 0; r < GRID_ROWS; r++) if (grid[r]?.[candy.col]) ids.add(grid[r][candy.col].id);
  } else if (candy.special === 'bomb') {
    for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      const nr = candy.row + dr, nc = candy.col + dc;
      if (nr >= 0 && nr < GRID_ROWS && nc >= 0 && nc < GRID_COLS && grid[nr]?.[nc]) ids.add(grid[nr][nc].id);
    }
  } else if (candy.special === 'wrapped') {
    for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) {
      const nr = candy.row + dr, nc = candy.col + dc;
      if (nr >= 0 && nr < GRID_ROWS && nc >= 0 && nc < GRID_COLS && grid[nr]?.[nc]) ids.add(grid[nr][nc].id);
    }
  } else if (candy.special === 'rainbow') {
    const t = CANDY_TYPES[Math.floor(Math.random() * CANDY_TYPES.length)];
    for (let r = 0; r < GRID_ROWS; r++) for (let c = 0; c < GRID_COLS; c++)
      if (grid[r]?.[c]?.type === t) ids.add(grid[r][c].id);
  }
  return ids;
}

export function applyGravity(grid: Candy[][]): Candy[][] {
  const g = grid.map(r => [...r]);
  for (let c = 0; c < GRID_COLS; c++) {
    let write = GRID_ROWS - 1;
    for (let r = GRID_ROWS - 1; r >= 0; r--) {
      if (g[r][c] && !g[r][c].isMatched) {
        g[write][c] = write !== r ? { ...g[r][c], row: write, isNew: false } : g[r][c];
        if (write !== r) g[r][c] = null as any;
        write--;
      }
    }
    for (let r = write; r >= 0; r--) g[r][c] = { ...makeCandy(r, c), isNew: true };
  }
  return g;
}

export function swap(grid: Candy[][], r1: number, c1: number, r2: number, c2: number): Candy[][] {
  const g = grid.map(r => [...r]);
  const tmp = { ...g[r1][c1], row: r2, col: c2 };
  g[r1][c1] = { ...g[r2][c2], row: r1, col: c1 };
  g[r2][c2] = tmp;
  return g;
}

export function isAdjacent(r1: number, c1: number, r2: number, c2: number) {
  return (Math.abs(r1-r2) === 1 && c1 === c2) || (Math.abs(c1-c2) === 1 && r1 === r2);
}

export function hasMoves(grid: Candy[][]): boolean {
  for (let r = 0; r < GRID_ROWS; r++) for (let c = 0; c < GRID_COLS; c++) {
    if (c < GRID_COLS - 1 && findMatches(swap(grid, r, c, r, c+1)).size > 0) return true;
    if (r < GRID_ROWS - 1 && findMatches(swap(grid, r, c, r+1, c)).size > 0) return true;
  }
  return false;
}

export function calcScore(count: number, combo: number, hasSpecial: boolean): number {
  return Math.floor(count * 30 * Math.pow(combo, 1.5) * (hasSpecial ? 3 : 1));
}
