import React, { createContext, useContext, useCallback, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import {
  Candy,
  GRID_COLS,
  GRID_ROWS,
  LEVELS,
} from '@/constants/gameConfig';
import {
  createInitialGrid,
  findMatches,
  applyGravity,
  removeMatched,
  swapCandies,
  isAdjacent,
  hasMoves,
  applySpecialEffect,
  countScore,
  determineSpecial,
  getMatchLength,
} from '@/utils/gameEngine';

export type GamePhase = 'home' | 'playing' | 'paused' | 'levelComplete' | 'gameOver';

interface Particle {
  id: string;
  x: number;
  y: number;
  color: string;
  type: 'burst' | 'star' | 'heart';
}

interface GameContextValue {
  grid: Candy[][];
  score: number;
  highScore: number;
  moves: number;
  maxMoves: number;
  level: number;
  combo: number;
  phase: GamePhase;
  selected: { row: number; col: number } | null;
  particles: Particle[];
  levelTarget: number;
  explodingIds: Set<string>;
  specialCreatedIds: Set<string>;
  shuffling: boolean;
  handleCandyPress: (row: number, col: number) => void;
  startGame: (level?: number) => void;
  nextLevel: () => void;
  restartLevel: () => void;
  goHome: () => void;
  pauseGame: () => void;
  resumeGame: () => void;
}

const GameContext = createContext<GameContextValue | null>(null);

const STORAGE_KEY = 'candyblast_highscore';

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [grid, setGrid] = useState<Candy[][]>([]);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [moves, setMoves] = useState(0);
  const [maxMoves, setMaxMoves] = useState(20);
  const [level, setLevel] = useState(1);
  const [combo, setCombo] = useState(0);
  const [phase, setPhase] = useState<GamePhase>('home');
  const [selected, setSelected] = useState<{ row: number; col: number } | null>(null);
  const [particles, setParticles] = useState<Particle[]>([]);
  const [explodingIds, setExplodingIds] = useState<Set<string>>(new Set());
  const [specialCreatedIds, setSpecialCreatedIds] = useState<Set<string>>(new Set());
  const [shuffling, setShuffling] = useState(false);

  const processingRef = useRef(false);

  const levelConfig = LEVELS[Math.min(level - 1, LEVELS.length - 1)];
  const levelTarget = levelConfig.target;

  React.useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then(val => {
      if (val) setHighScore(parseInt(val, 10));
    });
  }, []);

  const saveHighScore = useCallback(async (s: number) => {
    await AsyncStorage.setItem(STORAGE_KEY, s.toString());
    setHighScore(s);
  }, []);

  const spawnParticles = useCallback((row: number, col: number, color: string, count = 6) => {
    const newParticles: Particle[] = Array.from({ length: count }, (_, i) => ({
      id: Date.now().toString() + i + Math.random(),
      x: col * 44 + 22,
      y: row * 44 + 22,
      color,
      type: (['burst', 'star', 'heart'] as const)[i % 3],
    }));
    setParticles(prev => [...prev, ...newParticles]);
    setTimeout(() => {
      setParticles(prev => prev.filter(p => !newParticles.find(np => np.id === p.id)));
    }, 800);
  }, []);

  const processGrid = useCallback(async (g: Candy[][], currentCombo: number, currentScore: number) => {
    if (processingRef.current) return;
    processingRef.current = true;

    let workingGrid = g;
    let workingCombo = currentCombo;
    let workingScore = currentScore;
    let continueLoop = true;

    while (continueLoop) {
      const matched = findMatches(workingGrid);
      if (matched.size === 0) {
        continueLoop = false;
        break;
      }

      // Haptic feedback
      if (workingCombo === 0) {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
      } else if (workingCombo === 1) {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
      } else {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }

      workingCombo++;

      // Check for specials in matches
      let allExploded = new Set(matched);
      let hasSpecial = false;
      const newSpecialIds = new Set<string>();

      workingGrid.forEach(row => row.forEach(candy => {
        if (candy?.special && matched.has(candy.id)) {
          hasSpecial = true;
          const { explodedIds } = applySpecialEffect(workingGrid, candy);
          explodedIds.forEach(id => allExploded.add(id));
        }
      }));

      // Determine if new specials should be created
      const specialCandidates: { id: string; matchLen: number }[] = [];
      matched.forEach(id => {
        const matchLen = getMatchLength(workingGrid, id);
        if (matchLen >= 4) {
          specialCandidates.push({ id, matchLen });
        }
      });

      setExplodingIds(new Set(allExploded));

      const points = countScore(allExploded.size, workingCombo, hasSpecial);
      workingScore += points;

      await new Promise(r => setTimeout(r, 350));

      workingGrid = removeMatched(workingGrid, allExploded);

      // Create specials for long matches
      if (specialCandidates.length > 0) {
        const { id, matchLen } = specialCandidates[0];
        workingGrid.forEach(row => row.forEach(candy => {
          if (candy?.id === id) {
            const special = determineSpecial(matchLen, false);
            if (special) {
              candy.special = special;
              candy.isMatched = false;
              newSpecialIds.add(id);
            }
          }
        }));
      }

      const { grid: fallen, changed } = applyGravity(workingGrid);
      workingGrid = fallen;

      setSpecialCreatedIds(newSpecialIds);
      setGrid([...workingGrid]);
      setScore(workingScore);
      setCombo(workingCombo);
      setExplodingIds(new Set());

      await new Promise(r => setTimeout(r, 300));
    }

    setCombo(0);

    if (workingScore > highScore) {
      saveHighScore(workingScore);
    }

    processingRef.current = false;
    return workingScore;
  }, [highScore, saveHighScore]);

  const handleCandyPress = useCallback(async (row: number, col: number) => {
    if (processingRef.current || phase !== 'playing' || moves >= maxMoves) return;

    if (!selected) {
      setSelected({ row, col });
      Haptics.selectionAsync();
      return;
    }

    const { row: sr, col: sc } = selected;
    setSelected(null);

    if (sr === row && sc === col) return;

    if (!isAdjacent(sr, sc, row, col)) {
      setSelected({ row, col });
      Haptics.selectionAsync();
      return;
    }

    const swapped = swapCandies(grid, sr, sc, row, col);
    const matches = findMatches(swapped);

    if (matches.size === 0) {
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    const newMoves = moves + 1;
    setMoves(newMoves);
    setGrid([...swapped]);

    const finalScore = await processGrid(swapped, 0, score);

    const fs = finalScore ?? score;

    if (fs >= levelTarget) {
      setPhase('levelComplete');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      return;
    }

    if (newMoves >= maxMoves) {
      if (!hasMoves(swapped)) {
        setPhase('gameOver');
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        return;
      }
      setPhase('gameOver');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    if (!hasMoves(swapped)) {
      // Shuffle board
      setShuffling(true);
      await new Promise(r => setTimeout(r, 500));
      setGrid(createInitialGrid());
      setShuffling(false);
    }
  }, [grid, selected, phase, moves, maxMoves, score, levelTarget, processGrid]);

  const startGame = useCallback((lvl = 1) => {
    const config = LEVELS[Math.min(lvl - 1, LEVELS.length - 1)];
    setLevel(lvl);
    setMaxMoves(config.moves);
    setScore(0);
    setMoves(0);
    setCombo(0);
    setSelected(null);
    setParticles([]);
    setExplodingIds(new Set());
    setSpecialCreatedIds(new Set());
    setGrid(createInitialGrid());
    setPhase('playing');
    processingRef.current = false;
  }, []);

  const nextLevel = useCallback(() => {
    const nextLvl = level + 1;
    startGame(nextLvl);
  }, [level, startGame]);

  const restartLevel = useCallback(() => {
    startGame(level);
  }, [level, startGame]);

  const goHome = useCallback(() => {
    setPhase('home');
    setSelected(null);
    processingRef.current = false;
  }, []);

  const pauseGame = useCallback(() => setPhase('paused'), []);
  const resumeGame = useCallback(() => setPhase('playing'), []);

  return (
    <GameContext.Provider value={{
      grid,
      score,
      highScore,
      moves,
      maxMoves,
      level,
      combo,
      phase,
      selected,
      particles,
      levelTarget,
      explodingIds,
      specialCreatedIds,
      shuffling,
      handleCandyPress,
      startGame,
      nextLevel,
      restartLevel,
      goHome,
      pauseGame,
      resumeGame,
    }}>
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error('useGame must be used within GameProvider');
  return ctx;
}
