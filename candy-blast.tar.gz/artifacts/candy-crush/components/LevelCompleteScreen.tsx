import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withSequence,
  withTiming,
  withDelay,
  withRepeat,
  interpolate,
} from 'react-native-reanimated';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useGame } from '@/context/GameContext';
import { LEVELS } from '@/constants/gameConfig';

function StarBurst({ delay = 0, color = '#FFD700' }: { delay?: number; color?: string }) {
  const scale = useSharedValue(0);
  const opacity = useSharedValue(0);

  useEffect(() => {
    scale.value = withDelay(delay, withSpring(1.3, { damping: 6, stiffness: 200 }));
    opacity.value = withDelay(delay, withTiming(1, { duration: 400 }));
  }, []);

  const style = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
    opacity: opacity.value,
  }));

  return (
    <Animated.Text style={[styles.star, { color }, style]}>★</Animated.Text>
  );
}

export function LevelCompleteScreen() {
  const { score, level, nextLevel, goHome, moves, maxMoves } = useGame();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  const containerScale = useSharedValue(0.3);
  const containerOpacity = useSharedValue(0);
  const bounceY = useSharedValue(0);
  const rotation = useSharedValue(-10);

  const nextLevel_ = Math.min(level + 1, LEVELS.length);
  const nextConfig = LEVELS[nextLevel_ - 1];
  const movesUsed = moves;
  const starsEarned = movesUsed <= maxMoves * 0.5 ? 3 : movesUsed <= maxMoves * 0.75 ? 2 : 1;

  useEffect(() => {
    containerScale.value = withSpring(1, { damping: 10, stiffness: 150 });
    containerOpacity.value = withTiming(1, { duration: 400 });
    bounceY.value = withRepeat(
      withSequence(
        withSpring(-8, { damping: 6, stiffness: 200 }),
        withSpring(0, { damping: 6, stiffness: 200 })
      ),
      -1,
      false
    );
    rotation.value = withSpring(0, { damping: 8, stiffness: 150 });
  }, []);

  const containerStyle = useAnimatedStyle(() => ({
    transform: [{ scale: containerScale.value }],
    opacity: containerOpacity.value,
  }));

  const titleStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: bounceY.value }, { rotate: `${rotation.value}deg` }],
  }));

  return (
    <View style={[styles.overlay, { paddingTop: topPad }]}>
      <Animated.View style={[styles.card, containerStyle]}>
        {/* Stars */}
        <View style={styles.starsRow}>
          {[0, 1, 2].map(i => (
            i < starsEarned
              ? <StarBurst key={i} delay={i * 200} color="#FFD700" />
              : <Text key={i} style={[styles.star, { color: 'rgba(255,215,0,0.2)' }]}>★</Text>
          ))}
        </View>

        {/* Title */}
        <Animated.Text style={[styles.title, titleStyle]}>
          LEVEL {level} COMPLETE!
        </Animated.Text>

        {/* Score */}
        <View style={styles.scoreBox}>
          <Text style={styles.scoreLabel}>Score</Text>
          <Text style={styles.score}>{score.toLocaleString()}</Text>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          <View style={styles.statBox}>
            <MaterialCommunityIcons name="swap-horizontal" size={20} color="#9B59B6" />
            <Text style={styles.statValue}>{movesUsed}</Text>
            <Text style={styles.statLabel}>Moves Used</Text>
          </View>
          <View style={styles.statBox}>
            <MaterialCommunityIcons name="star" size={20} color="#FFD700" />
            <Text style={styles.statValue}>{starsEarned}/3</Text>
            <Text style={styles.statLabel}>Stars</Text>
          </View>
          <View style={styles.statBox}>
            <MaterialCommunityIcons name="trophy" size={20} color="#FF6B6B" />
            <Text style={styles.statValue}>LVL {nextLevel_}</Text>
            <Text style={styles.statLabel}>Unlocked</Text>
          </View>
        </View>

        {/* Next level preview */}
        {level < LEVELS.length && (
          <View style={styles.nextLevelPreview}>
            <Text style={styles.nextLevelLabel}>Next: {nextConfig.description}</Text>
            <Text style={styles.nextLevelTarget}>{nextConfig.target.toLocaleString()} pts target</Text>
          </View>
        )}

        {/* Buttons */}
        <View style={styles.buttons}>
          <TouchableOpacity style={styles.homeBtn} onPress={goHome} activeOpacity={0.8}>
            <MaterialCommunityIcons name="home" size={22} color="#9B59B6" />
          </TouchableOpacity>

          {level < LEVELS.length ? (
            <TouchableOpacity style={styles.nextBtn} onPress={nextLevel} activeOpacity={0.85}>
              <Text style={styles.nextBtnText}>NEXT LEVEL</Text>
              <MaterialCommunityIcons name="arrow-right" size={22} color="#fff" />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity style={styles.nextBtn} onPress={goHome} activeOpacity={0.85}>
              <Text style={styles.nextBtnText}>YOU WIN!</Text>
              <MaterialCommunityIcons name="trophy" size={22} color="#fff" />
            </TouchableOpacity>
          )}
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15, 5, 30, 0.92)',
  },
  card: {
    backgroundColor: '#2d0f50',
    borderRadius: 24,
    padding: 28,
    width: '88%',
    alignItems: 'center',
    gap: 16,
    borderWidth: 2,
    borderColor: 'rgba(155, 89, 182, 0.5)',
    shadowColor: '#9B59B6',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.6,
    shadowRadius: 24,
    elevation: 15,
  },
  starsRow: {
    flexDirection: 'row',
    gap: 12,
    alignItems: 'center',
  },
  star: {
    fontSize: 44,
  },
  title: {
    color: '#FFD700',
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: 1,
    textAlign: 'center',
    textShadowColor: 'rgba(255,215,0,0.5)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 12,
  },
  scoreBox: {
    alignItems: 'center',
    backgroundColor: 'rgba(155, 89, 182, 0.15)',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(155, 89, 182, 0.3)',
  },
  scoreLabel: {
    color: '#b8a0d8',
    fontSize: 12,
    fontWeight: '500',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  score: {
    color: '#ffffff',
    fontSize: 40,
    fontWeight: '800',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
    justifyContent: 'center',
  },
  statBox: {
    alignItems: 'center',
    flex: 1,
    backgroundColor: 'rgba(155, 89, 182, 0.1)',
    paddingVertical: 10,
    borderRadius: 12,
    gap: 2,
  },
  statValue: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '700',
  },
  statLabel: {
    color: '#b8a0d8',
    fontSize: 10,
    fontWeight: '500',
  },
  nextLevelPreview: {
    backgroundColor: 'rgba(255, 215, 0, 0.1)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.2)',
    width: '100%',
  },
  nextLevelLabel: {
    color: '#FFD700',
    fontSize: 14,
    fontWeight: '700',
  },
  nextLevelTarget: {
    color: '#b8a0d8',
    fontSize: 11,
  },
  buttons: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  homeBtn: {
    backgroundColor: 'rgba(155, 89, 182, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(155, 89, 182, 0.4)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  nextBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#9B59B6',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#9B59B6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 6,
  },
  nextBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 1,
  },
});
