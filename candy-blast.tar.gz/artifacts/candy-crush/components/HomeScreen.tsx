import React, { useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
} from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withSpring,
  withTiming,
  interpolate,
} from 'react-native-reanimated';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useGame } from '@/context/GameContext';
import { LEVELS } from '@/constants/gameConfig';

const CANDY_EMOJIS = ['♥', '◆', '●', '★', '⬡', '■'];
const CANDY_COLORS_LIST = ['#FF6B6B', '#5AA0FF', '#2ECC71', '#FFD700', '#9B59B6', '#FF8C00'];

function FloatingCandy({ index }: { index: number }) {
  const translateY = useSharedValue(0);
  const translateX = useSharedValue(0);
  const rotation = useSharedValue(0);
  const scale = useSharedValue(0.5 + Math.random() * 0.5);

  const startY = 300 + Math.random() * 400;
  const startX = Math.random() * 350;
  const duration = 3000 + Math.random() * 4000;

  translateY.value = startY;
  translateX.value = startX;

  useEffect(() => {
    translateY.value = withRepeat(
      withTiming(-100, { duration }),
      -1,
      false
    );
    rotation.value = withRepeat(
      withTiming(360, { duration: 4000 }),
      -1,
      false
    );
  }, []);

  const style = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { rotate: `${rotation.value}deg` },
      { scale: scale.value },
    ],
    opacity: interpolate(translateY.value, [-100, 100, startY], [0, 1, 0]),
  }));

  return (
    <Animated.Text
      style={[
        styles.floatingCandy,
        { color: CANDY_COLORS_LIST[index % CANDY_COLORS_LIST.length] },
        style,
      ]}
    >
      {CANDY_EMOJIS[index % CANDY_EMOJIS.length]}
    </Animated.Text>
  );
}

function PulsingTitle() {
  const glow = useSharedValue(0);

  useEffect(() => {
    glow.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 1200 }),
        withTiming(0, { duration: 1200 })
      ),
      -1,
      false
    );
  }, []);

  const style = useAnimatedStyle(() => ({
    shadowOpacity: interpolate(glow.value, [0, 1], [0.3, 1]),
    shadowRadius: interpolate(glow.value, [0, 1], [8, 25]),
  }));

  return (
    <Animated.Text style={[styles.title, style]}>
      CANDY BLAST
    </Animated.Text>
  );
}

export function HomeScreen() {
  const { startGame, highScore } = useGame();
  const insets = useSafeAreaInsets();

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  const buttonScale = useSharedValue(1);
  const buttonStyle = useAnimatedStyle(() => ({
    transform: [{ scale: buttonScale.value }],
  }));

  useEffect(() => {
    buttonScale.value = withRepeat(
      withSequence(
        withSpring(1.04, { damping: 8, stiffness: 200 }),
        withSpring(1, { damping: 8, stiffness: 200 })
      ),
      -1,
      false
    );
  }, []);

  return (
    <View style={[styles.container, { paddingTop: topPad + 40, paddingBottom: botPad + 20 }]}>
      {/* Floating candies background */}
      {Array.from({ length: 10 }).map((_, i) => (
        <FloatingCandy key={i} index={i} />
      ))}

      {/* Logo area */}
      <View style={styles.logoArea}>
        <Text style={styles.iconRow}>♥◆●★</Text>
        <PulsingTitle />
        <Text style={styles.subtitle}>Satisfy your sweet cravings</Text>
      </View>

      {/* High score */}
      {highScore > 0 && (
        <View style={styles.highScoreBox}>
          <MaterialCommunityIcons name="trophy" size={20} color="#FFD700" />
          <Text style={styles.highScoreLabel}>Best Score</Text>
          <Text style={styles.highScoreValue}>{highScore.toLocaleString()}</Text>
        </View>
      )}

      {/* Play button */}
      <Animated.View style={buttonStyle}>
        <TouchableOpacity
          style={styles.playButton}
          onPress={() => startGame(1)}
          activeOpacity={0.85}
        >
          <MaterialCommunityIcons name="play" size={28} color="#fff" />
          <Text style={styles.playText}>PLAY NOW</Text>
        </TouchableOpacity>
      </Animated.View>

      {/* Level selector */}
      <View style={styles.levelsSection}>
        <Text style={styles.levelsTitle}>Choose Level</Text>
        <View style={styles.levelsGrid}>
          {LEVELS.map((lvl, i) => (
            <TouchableOpacity
              key={i}
              style={styles.levelBtn}
              onPress={() => startGame(i + 1)}
              activeOpacity={0.8}
            >
              <Text style={styles.levelBtnNum}>{i + 1}</Text>
              <Text style={styles.levelBtnName}>{lvl.description}</Text>
              <Text style={styles.levelBtnTarget}>{(lvl.target / 1000).toFixed(0)}K pts</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      {/* Feature badges */}
      <View style={styles.badges}>
        {['Combos', 'Specials', 'Power-ups'].map(b => (
          <View key={b} style={styles.badge}>
            <Text style={styles.badgeText}>{b}</Text>
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    gap: 20,
    overflow: 'hidden',
  },
  floatingCandy: {
    position: 'absolute',
    fontSize: 28,
    fontWeight: 'bold',
  },
  logoArea: {
    alignItems: 'center',
    gap: 6,
  },
  iconRow: {
    fontSize: 36,
    letterSpacing: 8,
    color: '#FFD700',
    textShadowColor: '#FFD700',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 12,
  },
  title: {
    fontSize: 42,
    fontWeight: '900',
    color: '#ffffff',
    letterSpacing: 3,
    textAlign: 'center',
    shadowColor: '#FF6B6B',
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 20,
    shadowOpacity: 0.8,
    textShadowColor: 'rgba(255, 107, 107, 0.6)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 15,
  },
  subtitle: {
    color: '#d4b8f0',
    fontSize: 15,
    fontWeight: '400',
    letterSpacing: 1,
  },
  highScoreBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(255, 215, 0, 0.15)',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  highScoreLabel: {
    color: '#FFD700',
    fontSize: 13,
    fontWeight: '500',
  },
  highScoreValue: {
    color: '#FFD700',
    fontSize: 18,
    fontWeight: '800',
  },
  playButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 48,
    paddingVertical: 18,
    borderRadius: 40,
    shadowColor: '#FF6B6B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.7,
    shadowRadius: 15,
    elevation: 10,
  },
  playText: {
    color: '#fff',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: 2,
  },
  levelsSection: {
    width: '100%',
    gap: 10,
  },
  levelsTitle: {
    color: '#b8a0d8',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 2,
    textAlign: 'center',
    textTransform: 'uppercase',
  },
  levelsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 8,
  },
  levelBtn: {
    backgroundColor: 'rgba(155, 89, 182, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(155, 89, 182, 0.4)',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    alignItems: 'center',
    width: 90,
    gap: 2,
  },
  levelBtnNum: {
    color: '#9B59B6',
    fontSize: 18,
    fontWeight: '800',
  },
  levelBtnName: {
    color: '#d4b8f0',
    fontSize: 9,
    fontWeight: '500',
    textAlign: 'center',
  },
  levelBtnTarget: {
    color: '#b8a0d8',
    fontSize: 9,
    fontWeight: '400',
  },
  badges: {
    flexDirection: 'row',
    gap: 8,
  },
  badge: {
    backgroundColor: 'rgba(155, 89, 182, 0.15)',
    borderRadius: 20,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderWidth: 1,
    borderColor: 'rgba(155, 89, 182, 0.3)',
  },
  badgeText: {
    color: '#9B59B6',
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
});
