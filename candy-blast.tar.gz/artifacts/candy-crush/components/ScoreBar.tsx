import React, { useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import { useGame } from '@/context/GameContext';
import { useColors } from '@/hooks/useColors';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { LEVELS } from '@/constants/gameConfig';

export function ScoreBar() {
  const { score, highScore, moves, maxMoves, level, combo, levelTarget } = useGame();
  const colors = useColors();

  const comboScale = useSharedValue(1);
  const scoreScale = useSharedValue(1);
  const prevScore = React.useRef(score);

  useEffect(() => {
    if (combo > 1) {
      comboScale.value = withSequence(
        withSpring(1.6, { damping: 6, stiffness: 400 }),
        withSpring(1, { damping: 10, stiffness: 200 })
      );
    }
  }, [combo]);

  useEffect(() => {
    if (score !== prevScore.current) {
      scoreScale.value = withSequence(
        withSpring(1.25, { damping: 8, stiffness: 400 }),
        withSpring(1, { damping: 12, stiffness: 200 })
      );
      prevScore.current = score;
    }
  }, [score]);

  const comboStyle = useAnimatedStyle(() => ({
    transform: [{ scale: comboScale.value }],
  }));

  const scoreStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scoreScale.value }],
  }));

  const progress = Math.min(score / levelTarget, 1);
  const levelName = LEVELS[Math.min(level - 1, LEVELS.length - 1)].description;
  const movesLeft = maxMoves - moves;
  const movesWarning = movesLeft <= 5;

  return (
    <View style={styles.container}>
      {/* Top row: Level name + High Score */}
      <View style={styles.topRow}>
        <View style={styles.levelBadge}>
          <Text style={styles.levelNum}>LVL {level}</Text>
          <Text style={styles.levelName}>{levelName}</Text>
        </View>
        <View style={styles.highScoreBox}>
          <MaterialCommunityIcons name="trophy" size={14} color="#FFD700" />
          <Text style={styles.highScoreText}>{highScore.toLocaleString()}</Text>
        </View>
      </View>

      {/* Score */}
      <View style={styles.scoreRow}>
        <Animated.Text style={[styles.score, scoreStyle]}>
          {score.toLocaleString()}
        </Animated.Text>
        {combo > 1 && (
          <Animated.View style={[styles.comboBadge, comboStyle]}>
            <Text style={styles.comboText}>x{combo} COMBO!</Text>
          </Animated.View>
        )}
      </View>

      {/* Progress bar */}
      <View style={styles.progressContainer}>
        <View style={styles.progressTrack}>
          <Animated.View
            style={[
              styles.progressFill,
              { width: `${progress * 100}%` },
            ]}
          />
          <View style={[styles.progressStar, { left: `${progress * 100}%` }]}>
            <Text style={styles.progressStarText}>★</Text>
          </View>
        </View>
        <Text style={styles.progressLabel}>
          {Math.floor(progress * 100)}% to goal
        </Text>
      </View>

      {/* Moves remaining */}
      <View style={styles.movesRow}>
        <Ionicons
          name="swap-horizontal"
          size={16}
          color={movesWarning ? '#FF6B6B' : '#b8a0d8'}
        />
        <Text style={[styles.movesText, movesWarning && styles.movesWarning]}>
          {movesLeft} moves left
        </Text>
        <View style={styles.movesDots}>
          {Array.from({ length: Math.min(maxMoves, 10) }).map((_, i) => {
            const dotIdx = maxMoves - moves - 1;
            const pct = i / (Math.min(maxMoves, 10) - 1);
            const threshold = (maxMoves - moves) / maxMoves;
            return (
              <View
                key={i}
                style={[
                  styles.moveDot,
                  {
                    backgroundColor:
                      i < Math.ceil((movesLeft / maxMoves) * 10)
                        ? movesWarning ? '#FF6B6B' : '#9B59B6'
                        : 'rgba(155,89,182,0.2)',
                  },
                ]}
              />
            );
          })}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'rgba(45, 15, 80, 0.9)',
    borderRadius: 20,
    padding: 16,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: 'rgba(155, 89, 182, 0.3)',
    shadowColor: '#6B4FBB',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 5,
    gap: 8,
  },
  topRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(155, 89, 182, 0.3)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  levelNum: {
    color: '#9B59B6',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
  },
  levelName: {
    color: '#d4b8f0',
    fontSize: 11,
    fontWeight: '500',
  },
  highScoreBox: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  highScoreText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
  },
  scoreRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  score: {
    color: '#ffffff',
    fontSize: 36,
    fontWeight: '800',
    letterSpacing: -0.5,
  },
  comboBadge: {
    backgroundColor: '#FF6B6B',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 20,
    shadowColor: '#FF6B6B',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
    elevation: 6,
  },
  comboText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  progressContainer: {
    gap: 4,
  },
  progressTrack: {
    height: 8,
    backgroundColor: 'rgba(155, 89, 182, 0.2)',
    borderRadius: 4,
    overflow: 'visible',
    position: 'relative',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#9B59B6',
    borderRadius: 4,
    shadowColor: '#9B59B6',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  progressStar: {
    position: 'absolute',
    top: -10,
    transform: [{ translateX: -8 }],
  },
  progressStarText: {
    color: '#FFD700',
    fontSize: 18,
  },
  progressLabel: {
    color: '#b8a0d8',
    fontSize: 11,
    textAlign: 'right',
  },
  movesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  movesText: {
    color: '#b8a0d8',
    fontSize: 13,
    fontWeight: '500',
    flex: 1,
  },
  movesWarning: {
    color: '#FF6B6B',
    fontWeight: '700',
  },
  movesDots: {
    flexDirection: 'row',
    gap: 3,
  },
  moveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
});
