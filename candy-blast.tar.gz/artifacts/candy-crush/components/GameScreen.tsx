import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useGame } from '@/context/GameContext';
import { GameBoard } from './GameBoard';
import { ScoreBar } from './ScoreBar';
import { LevelCompleteScreen } from './LevelCompleteScreen';
import { GameOverScreen } from './GameOverScreen';

export function GameScreen() {
  const { phase, shuffling, goHome, pauseGame, resumeGame } = useGame();
  const insets = useSafeAreaInsets();

  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const botPad = Platform.OS === 'web' ? 34 : insets.bottom;

  if (phase === 'levelComplete') return <LevelCompleteScreen />;
  if (phase === 'gameOver') return <GameOverScreen />;

  return (
    <View style={[styles.container, { paddingTop: topPad + 8, paddingBottom: botPad + 8 }]}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={goHome} style={styles.iconBtn}>
          <MaterialCommunityIcons name="home" size={22} color="rgba(255,255,255,0.7)" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>CANDY BLAST</Text>
        {phase === 'paused' ? (
          <TouchableOpacity onPress={resumeGame} style={styles.iconBtn}>
            <MaterialCommunityIcons name="play" size={22} color="rgba(255,255,255,0.7)" />
          </TouchableOpacity>
        ) : (
          <TouchableOpacity onPress={pauseGame} style={styles.iconBtn}>
            <MaterialCommunityIcons name="pause" size={22} color="rgba(255,255,255,0.7)" />
          </TouchableOpacity>
        )}
      </View>

      {/* Score */}
      <ScoreBar />

      {/* Board area */}
      <View style={styles.boardWrapper}>
        <GameBoard />

        {/* Shuffle overlay */}
        {shuffling && (
          <View style={styles.shuffleOverlay}>
            <MaterialCommunityIcons name="shuffle-variant" size={40} color="#FFD700" />
            <Text style={styles.shuffleText}>Shuffling...</Text>
          </View>
        )}

        {/* Pause overlay */}
        {phase === 'paused' && (
          <View style={styles.pauseOverlay}>
            <MaterialCommunityIcons name="pause-circle" size={60} color="rgba(255,255,255,0.8)" />
            <Text style={styles.pauseText}>PAUSED</Text>
            <TouchableOpacity onPress={resumeGame} style={styles.resumeBtn}>
              <Text style={styles.resumeBtnText}>RESUME</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* Special guide */}
      <View style={styles.guide}>
        <Text style={styles.guideTitle}>Specials</Text>
        <View style={styles.guideItems}>
          {[
            { label: '4 in a row → Striped', color: '#5AA0FF' },
            { label: '5 in a row → Rainbow', color: '#FFD700' },
            { label: 'L-shape → Wrapped', color: '#2ECC71' },
          ].map(item => (
            <View key={item.label} style={styles.guideItem}>
              <View style={[styles.guideDot, { backgroundColor: item.color }]} />
              <Text style={styles.guideText}>{item.label}</Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 10,
    gap: 8,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  iconBtn: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(155, 89, 182, 0.2)',
    borderRadius: 12,
  },
  headerTitle: {
    color: '#ffffff',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 3,
    textShadowColor: 'rgba(155, 89, 182, 0.6)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 8,
  },
  boardWrapper: {
    alignItems: 'center',
    position: 'relative',
  },
  shuffleOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(15, 5, 30, 0.85)',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
    gap: 8,
  },
  shuffleText: {
    color: '#FFD700',
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: 1,
  },
  pauseOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(15, 5, 30, 0.9)',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 20,
    gap: 12,
  },
  pauseText: {
    color: '#ffffff',
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: 3,
  },
  resumeBtn: {
    backgroundColor: '#9B59B6',
    paddingHorizontal: 32,
    paddingVertical: 12,
    borderRadius: 20,
    marginTop: 8,
  },
  resumeBtnText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 1,
  },
  guide: {
    backgroundColor: 'rgba(45, 15, 80, 0.7)',
    borderRadius: 14,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: 'rgba(155, 89, 182, 0.2)',
  },
  guideTitle: {
    color: '#9B59B6',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 1.5,
    textTransform: 'uppercase',
    marginBottom: 6,
  },
  guideItems: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  guideItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },
  guideDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  guideText: {
    color: '#d4b8f0',
    fontSize: 10,
    fontWeight: '500',
  },
});
