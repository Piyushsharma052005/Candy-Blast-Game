import React, { useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  withRepeat,
  withSequence,
} from 'react-native-reanimated';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useGame } from '@/context/GameContext';

export function GameOverScreen() {
  const { score, highScore, level, restartLevel, goHome } = useGame();
  const insets = useSafeAreaInsets();
  const topPad = Platform.OS === 'web' ? 67 : insets.top;

  const containerScale = useSharedValue(0.3);
  const shake = useSharedValue(0);
  const iconScale = useSharedValue(0);

  useEffect(() => {
    containerScale.value = withSpring(1, { damping: 10, stiffness: 150 });
    shake.value = withRepeat(
      withSequence(
        withTiming(-8, { duration: 80 }),
        withTiming(8, { duration: 80 }),
        withTiming(-4, { duration: 60 }),
        withTiming(4, { duration: 60 }),
        withTiming(0, { duration: 40 })
      ),
      2,
      false
    );
    iconScale.value = withSpring(1, { damping: 6, stiffness: 200 });
  }, []);

  const containerStyle = useAnimatedStyle(() => ({
    transform: [{ scale: containerScale.value }, { translateX: shake.value }],
  }));

  const iconStyle = useAnimatedStyle(() => ({
    transform: [{ scale: iconScale.value }],
  }));

  const isNewHighScore = score >= highScore && score > 0;

  return (
    <View style={[styles.overlay, { paddingTop: topPad }]}>
      <Animated.View style={[styles.card, containerStyle]}>
        {/* Icon */}
        <Animated.View style={iconStyle}>
          <MaterialCommunityIcons name="emoticon-sad-outline" size={64} color="#FF6B6B" />
        </Animated.View>

        {/* Title */}
        <Text style={styles.title}>GAME OVER</Text>
        <Text style={styles.subtitle}>Level {level} - Better luck next time!</Text>

        {/* Score */}
        <View style={styles.scoreSection}>
          {isNewHighScore && (
            <View style={styles.newRecord}>
              <MaterialCommunityIcons name="trophy" size={16} color="#FFD700" />
              <Text style={styles.newRecordText}>NEW HIGH SCORE!</Text>
            </View>
          )}
          <View style={styles.scoreBox}>
            <Text style={styles.scoreLabel}>Your Score</Text>
            <Text style={styles.score}>{score.toLocaleString()}</Text>
          </View>
          <View style={styles.scoreBox}>
            <Text style={styles.scoreLabel}>Best Score</Text>
            <Text style={[styles.score, { color: '#FFD700', fontSize: 24 }]}>
              {highScore.toLocaleString()}
            </Text>
          </View>
        </View>

        {/* Tips */}
        <View style={styles.tipBox}>
          <MaterialCommunityIcons name="lightbulb-outline" size={16} color="#9B59B6" />
          <Text style={styles.tipText}>
            Tip: Match 4+ candies to create powerful special candies!
          </Text>
        </View>

        {/* Buttons */}
        <View style={styles.buttons}>
          <TouchableOpacity style={styles.homeBtn} onPress={goHome} activeOpacity={0.8}>
            <MaterialCommunityIcons name="home" size={22} color="#9B59B6" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.retryBtn} onPress={restartLevel} activeOpacity={0.85}>
            <MaterialCommunityIcons name="refresh" size={20} color="#fff" />
            <Text style={styles.retryText}>TRY AGAIN</Text>
          </TouchableOpacity>
        </View>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(15, 5, 30, 0.93)',
  },
  card: {
    backgroundColor: '#2d0f50',
    borderRadius: 24,
    padding: 28,
    width: '88%',
    alignItems: 'center',
    gap: 16,
    borderWidth: 2,
    borderColor: 'rgba(255, 107, 107, 0.4)',
    shadowColor: '#FF6B6B',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 24,
    elevation: 15,
  },
  title: {
    color: '#FF6B6B',
    fontSize: 36,
    fontWeight: '900',
    letterSpacing: 2,
    textShadowColor: 'rgba(255,107,107,0.5)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 12,
  },
  subtitle: {
    color: '#b8a0d8',
    fontSize: 14,
    fontWeight: '500',
  },
  scoreSection: {
    width: '100%',
    gap: 8,
    alignItems: 'center',
  },
  newRecord: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(255, 215, 0, 0.15)',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  newRecordText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 1,
  },
  scoreBox: {
    alignItems: 'center',
  },
  scoreLabel: {
    color: '#b8a0d8',
    fontSize: 11,
    fontWeight: '500',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  score: {
    color: '#ffffff',
    fontSize: 36,
    fontWeight: '800',
  },
  tipBox: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    backgroundColor: 'rgba(155, 89, 182, 0.1)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(155, 89, 182, 0.2)',
    width: '100%',
  },
  tipText: {
    color: '#d4b8f0',
    fontSize: 12,
    flex: 1,
    lineHeight: 18,
  },
  buttons: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  homeBtn: {
    backgroundColor: 'rgba(155, 89, 182, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(155, 89, 182, 0.4)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  retryBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: '#FF6B6B',
    borderRadius: 16,
    padding: 16,
    shadowColor: '#FF6B6B',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 10,
    elevation: 6,
  },
  retryText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 1,
  },
});
