import React from 'react';
import { View, StyleSheet, Platform } from 'react-native';
import { useGame } from '@/context/GameContext';
import { CandyCell } from './CandyCell';
import { GRID_COLS, GRID_ROWS } from '@/constants/gameConfig';

export function GameBoard() {
  const {
    grid,
    selected,
    explodingIds,
    specialCreatedIds,
    handleCandyPress,
  } = useGame();

  if (!grid || grid.length === 0) return null;

  return (
    <View style={styles.board}>
      {/* Grid background dots */}
      <View style={styles.gridBg}>
        {Array.from({ length: GRID_ROWS * GRID_COLS }).map((_, i) => (
          <View key={i} style={styles.gridDot} />
        ))}
      </View>
      {/* Candies */}
      <View style={styles.candyGrid}>
        {grid.map((row, r) => (
          <View key={r} style={styles.row}>
            {row.map((candy, c) => {
              if (!candy) return <View key={c} style={styles.emptyCell} />;
              const isSelected = selected?.row === r && selected?.col === c;
              const isExploding = explodingIds.has(candy.id);
              const isNewlyCreatedSpecial = specialCreatedIds.has(candy.id);
              return (
                <CandyCell
                  key={candy.id}
                  candy={candy}
                  isSelected={isSelected}
                  isExploding={isExploding}
                  isNewlyCreatedSpecial={isNewlyCreatedSpecial}
                  onPress={handleCandyPress}
                />
              );
            })}
          </View>
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  board: {
    position: 'relative',
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: 'rgba(45, 15, 80, 0.85)',
    borderWidth: 2,
    borderColor: 'rgba(155, 89, 182, 0.4)',
    shadowColor: '#9B59B6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 10,
    padding: 4,
  },
  gridBg: {
    position: 'absolute',
    top: 4,
    left: 4,
    flexDirection: 'row',
    flexWrap: 'wrap',
    width: GRID_COLS * 44,
    height: GRID_ROWS * 44,
    opacity: 0.15,
  },
  gridDot: {
    width: 44,
    height: 44,
    borderRadius: 0,
    borderWidth: 0.5,
    borderColor: '#9B59B6',
  },
  candyGrid: {
    position: 'relative',
    zIndex: 1,
  },
  row: {
    flexDirection: 'row',
  },
  emptyCell: {
    width: 44,
    height: 44,
  },
});
