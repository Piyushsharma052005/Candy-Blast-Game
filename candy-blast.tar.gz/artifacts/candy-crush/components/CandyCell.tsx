import React, { useEffect, useRef } from 'react';
import { Pressable, StyleSheet, View, Text, Platform } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
  withTiming,
  interpolateColor,
  runOnJS,
} from 'react-native-reanimated';
import { Candy, CandyType, CANDY_COLORS, SpecialType } from '@/constants/gameConfig';

const CELL_SIZE = 44;
const CANDY_SIZE = 38;

const CANDY_SYMBOLS: Record<CandyType, string> = {
  red: '♥',
  blue: '◆',
  green: '●',
  yellow: '★',
  purple: '⬡',
  orange: '■',
};

interface CandyCellProps {
  candy: Candy;
  isSelected: boolean;
  isExploding: boolean;
  isNewlyCreatedSpecial: boolean;
  onPress: (row: number, col: number) => void;
  cellSize?: number;
}

function SpecialOverlay({ special }: { special: SpecialType }) {
  if (!special) return null;
  const overlayStyle = [styles.specialOverlay];

  if (special === 'striped_h') {
    return (
      <View style={[styles.specialOverlay, styles.stripedH]}>
        <View style={styles.stripeLineH} />
        <View style={styles.stripeLineH} />
        <View style={styles.stripeLineH} />
      </View>
    );
  }
  if (special === 'striped_v') {
    return (
      <View style={[styles.specialOverlay, styles.stripedV]}>
        <View style={styles.stripeLineV} />
        <View style={styles.stripeLineV} />
        <View style={styles.stripeLineV} />
      </View>
    );
  }
  if (special === 'bomb') {
    return (
      <View style={styles.specialOverlay}>
        <Text style={styles.specialText}>💥</Text>
      </View>
    );
  }
  if (special === 'wrapped') {
    return (
      <View style={[styles.specialOverlay, styles.wrappedOverlay]}>
        <View style={styles.wrapLine} />
        <View style={[styles.wrapLine, { transform: [{ rotate: '90deg' }] }]} />
      </View>
    );
  }
  if (special === 'rainbow') {
    return (
      <View style={styles.specialOverlay}>
        <Text style={styles.specialText}>🌈</Text>
      </View>
    );
  }
  return null;
}

export const CandyCell = React.memo(function CandyCellInner({
  candy,
  isSelected,
  isExploding,
  isNewlyCreatedSpecial,
  onPress,
}: CandyCellProps) {
  const scale = useSharedValue(candy.isNew ? 0 : 1);
  const selectedScale = useSharedValue(1);
  const opacity = useSharedValue(1);
  const rotation = useSharedValue(0);
  const glow = useSharedValue(0);

  useEffect(() => {
    if (candy.isNew) {
      scale.value = withSpring(1, { damping: 12, stiffness: 200 });
    }
  }, [candy.isNew]);

  useEffect(() => {
    if (isSelected) {
      selectedScale.value = withSequence(
        withSpring(1.2, { damping: 10, stiffness: 300 }),
        withSpring(1.1, { damping: 12, stiffness: 200 })
      );
      glow.value = withTiming(1, { duration: 200 });
    } else {
      selectedScale.value = withSpring(1, { damping: 12, stiffness: 200 });
      glow.value = withTiming(0, { duration: 200 });
    }
  }, [isSelected]);

  useEffect(() => {
    if (isExploding) {
      scale.value = withSequence(
        withSpring(1.4, { damping: 8, stiffness: 400 }),
        withTiming(0, { duration: 200 })
      );
      opacity.value = withTiming(0, { duration: 350 });
      rotation.value = withTiming(360, { duration: 350 });
    }
  }, [isExploding]);

  useEffect(() => {
    if (isNewlyCreatedSpecial) {
      scale.value = withSequence(
        withSpring(1.5, { damping: 6, stiffness: 400 }),
        withSpring(1, { damping: 12, stiffness: 200 })
      );
    }
  }, [isNewlyCreatedSpecial]);

  const animStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: scale.value * selectedScale.value },
      { rotate: `${rotation.value}deg` },
    ],
    opacity: opacity.value,
  }));

  const glowStyle = useAnimatedStyle(() => ({
    shadowOpacity: glow.value * 0.8,
    shadowRadius: glow.value * 12,
    elevation: glow.value * 8,
  }));

  const baseColor = CANDY_COLORS[candy.type][0];
  const midColor = CANDY_COLORS[candy.type][1];
  const lightColor = CANDY_COLORS[candy.type][2];

  return (
    <Pressable onPress={() => onPress(candy.row, candy.col)}>
      <Animated.View style={[styles.cell, animStyle]}>
        <Animated.View
          style={[
            styles.candy,
            {
              backgroundColor: baseColor,
              shadowColor: baseColor,
            },
            glowStyle,
            isSelected && styles.selectedCandy,
          ]}
        >
          {/* Shine overlay */}
          <View style={[styles.shine, { backgroundColor: lightColor + '55' }]} />
          {/* Symbol */}
          <Text style={[styles.symbol, { color: '#ffffff' }]}>
            {CANDY_SYMBOLS[candy.type]}
          </Text>
          {/* Special overlay */}
          <SpecialOverlay special={candy.special} />
        </Animated.View>
      </Animated.View>
    </Pressable>
  );
});

const styles = StyleSheet.create({
  cell: {
    width: CELL_SIZE,
    height: CELL_SIZE,
    alignItems: 'center',
    justifyContent: 'center',
  },
  candy: {
    width: CANDY_SIZE,
    height: CANDY_SIZE,
    borderRadius: CANDY_SIZE / 2,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
    overflow: 'hidden',
  },
  selectedCandy: {
    borderWidth: 2.5,
    borderColor: '#ffffff',
  },
  shine: {
    position: 'absolute',
    top: 2,
    left: 4,
    width: 14,
    height: 10,
    borderRadius: 6,
    transform: [{ rotate: '-20deg' }],
  },
  symbol: {
    fontSize: 18,
    fontWeight: 'bold',
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },
  specialOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: CANDY_SIZE / 2,
    overflow: 'hidden',
  },
  stripedH: {
    flexDirection: 'column',
    gap: 3,
  },
  stripedV: {
    flexDirection: 'row',
    gap: 3,
  },
  stripeLineH: {
    width: '100%',
    height: 2.5,
    backgroundColor: 'rgba(255,255,255,0.7)',
  },
  stripeLineV: {
    width: 2.5,
    height: '100%',
    backgroundColor: 'rgba(255,255,255,0.7)',
  },
  wrappedOverlay: {
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.8)',
  },
  wrapLine: {
    position: 'absolute',
    width: '100%',
    height: 2.5,
    backgroundColor: 'rgba(255,255,255,0.8)',
  },
  specialText: {
    fontSize: 14,
  },
});
