import React from 'react';
import { View, StyleSheet, ImageBackground, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useGame } from '@/context/GameContext';
import { HomeScreen } from '@/components/HomeScreen';
import { GameScreen } from '@/components/GameScreen';

export default function MainScreen() {
  const { phase } = useGame();

  const isPlaying = phase === 'playing' || phase === 'paused' || phase === 'levelComplete' || phase === 'gameOver';

  return (
    <LinearGradient
      colors={['#0d0020', '#1a0533', '#2d0f50', '#1a0533']}
      locations={[0, 0.3, 0.7, 1]}
      style={styles.container}
    >
      {isPlaying ? <GameScreen /> : <HomeScreen />}
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
